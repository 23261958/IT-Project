<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocationUnitOfferingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('location_unit_offering', function (Blueprint $table) {
            $table->id();
            $table->foreignId('location_id')->constrained('locations' )->cascadeOnDelete();
            $table->foreignId('unit_offering_id')->constrained('unit_offerings')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('location_unit_offering');
    }
}
