<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUnitOfferingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('unit_offerings', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->foreignId('unit_id')->constrained('units')->cascadeOnDelete();
            $table->string('study_period');
            $table->year('year');
            $table->foreignId('unit_assessor_id')->constrained('staff')->cascadeOnDelete();
            $table->foreignId('lecturer_1_id')->nullable()->constrained('staff')->nullOnDelete();
            $table->foreignId('lecturer_2_id')->nullable()->constrained('staff')->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('unit_offerings');
    }
}
