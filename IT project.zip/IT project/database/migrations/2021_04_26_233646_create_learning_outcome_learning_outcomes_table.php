<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLearningOutcomeLearningOutcomesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('learning_outcome_learning_outcome', function (Blueprint $table) {
            $table->id();
            $table->foreignId('learning_outcome_1_id')->constrained('learning_outcomes')->cascadeOnDelete();
            $table->foreignId('learning_outcome_2_id')->constrained('learning_outcomes')->cascadeOnDelete();
            $table->integer('proficiency')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('learning_outcome_learning_outcome');
    }
}
