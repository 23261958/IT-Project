<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = [
            [
                'name'=> 'Administrator',
                'email'=> 'admin@email.com',
                'password'=> Hash::make('admin123')
            ],
            [
                'name'=> 'Unit_Designer_Example',
                'email'=> 'UDE@email.com',
                'password'=> Hash::make('ude123')
            ],
            [
                'name'=> 'Staff_Manager_Example',
                'email'=> 'SME@email.com',
                'password'=> Hash::make('sme123')
            ],
        ];

        foreach($users as $user){
            User::create($user);
        }
    }
}
