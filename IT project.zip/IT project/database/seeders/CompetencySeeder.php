<?php

namespace Database\Seeders;

use App\Models\Competency;
use Illuminate\Database\Seeder;

class CompetencySeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $competencies = [
            [
                'description' => 'description',
                'type' => 'competencies'
            ],
            [
                'description' => 'competency2',
                'type' => 'competencies'
            ],
            [
                'description' => 'competency3',
                'type' => 'competencies'
            ],
            [
                'description' => 'competency4',
                'type' => 'competencies'
            ]
        ];

    foreach($competencies as $competency){
        Competency::create($competency);
         }
    }
}
