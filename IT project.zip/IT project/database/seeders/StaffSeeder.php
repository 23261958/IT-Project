<?php

namespace Database\Seeders;

use App\Models\Staff;
use Illuminate\Database\Seeder;

class StaffSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $staff = [
            [
                'staff_role' => 'Lecturer',
                'first_name' => 'Alex',
                'last_name' => 'Hendry',
                'email' => 'alex.hendry@scu.edu.au',
                'phone' => '0428855176',
                'campus' => 'Gold Coast',
                'end_contract' => '2021-08-01',
                'proposed_extension' => '6 months'
            ],

            [
                'staff_role' => 'Lecturer',
                'first_name' => 'John',
                'last_name' => 'Doe',
                'email' => 'john.doe@email.com',
                'phone' => '0123456789',
                'campus' => 'Lismore',
                'end_contract' => '2022-03-01',
                'proposed_extension' => '12 months'
            ],
        ];

        foreach($staff as $member){
            Staff::create($member);
        }
    }
}
