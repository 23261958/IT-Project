<?php

namespace Database\Seeders;

use App\Models\Course;
use Illuminate\Database\Seeder;

class CourseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $courses = [
            [
                'course_code' => '2206400',
                'course_title' => 'Associate Degree of Civil Construction (Engineering and Management)',
                'course_type' => 'Associate Degree',
                'credit_points' => '192',
                'aqf_level' => '6'
                //'deleted' => 'no'


            ],
            [
                'course_code' => '3508001',
                'course_title' => 'Bachelor of Information Technology (Honours)',
                'course_type' => 'Bachelor (Honours) ',
                'credit_points' => '384',
                'aqf_level' => '8'
                //'deleted' => 'no'

            ],

        ];

        foreach($courses as $course){
            Course::create($course);
        }
    }
}
