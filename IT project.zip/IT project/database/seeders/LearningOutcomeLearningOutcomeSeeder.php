<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LearningOutcomeLearningOutcomeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $learningOutcomeLearningOutcomes = [
            [
                'learning_outcome_1_id'=> '1',
                'learning_outcome_2_id'=> '1',
                'proficiency'=> null
            ],
            [
                'learning_outcome_1_id'=> '1',
                'learning_outcome_2_id'=> '2',
                'proficiency'=> null
            ],
            [
                'learning_outcome_1_id'=> '2',
                'learning_outcome_2_id'=> '3',
                'proficiency'=> '1'
            ],
            [
                'learning_outcome_1_id'=> '3',
                'learning_outcome_2_id'=> '1',
                'proficiency'=> '3'
            ]
        ];

        foreach($learningOutcomeLearningOutcomes as $link) {
            DB::insert('INSERT INTO learning_outcome_learning_outcome (learning_outcome_1_id, learning_outcome_2_id, proficiency) VALUES (?, ?, ?)', [$link['learning_outcome_1_id'], $link['learning_outcome_2_id'], $link['proficiency']]);
        }
    }
}
