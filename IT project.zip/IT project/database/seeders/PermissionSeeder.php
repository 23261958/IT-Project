<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissions = [
            [
                'permission_name' => 'Add User',
                'permission_function' => 'addUser',
                'permission_description' => 'Can add users into the system'
            ],
            [
                'permission_name' => 'Read User',
                'permission_function' => 'readUser',
                'permission_description' => 'Can view the users in the system'
            ],
            [
                'permission_name' => 'Update User',
                'permission_function' => 'updateUser',
                'permission_description' => 'Can update users in the system'
            ],
            [
                'permission_name' => 'Delete User',
                'permission_function' => 'deleteUser',
                'permission_description' => 'Can delete users in the system'
            ],
            [
                'permission_name' => 'Add Course',
                'permission_function' => 'addCourse',
                'permission_description' => 'Can add courses in the system'
            ],
            [
                'permission_name' => 'Read Course',
                'permission_function' => 'readCourse',
                'permission_description' => 'Can view courses in the system'
            ],
            [
                'permission_name' => 'Update Course',
                'permission_function' => 'updateCourse',
                'permission_description' => 'Can update courses in the system'
            ],
            [
                'permission_name' => 'Delete Course',
                'permission_function' => 'deleteCourse',
                'permission_description' => 'Can delete courses in the system'
            ],
            [
                'permission_name' => 'Add Unit',
                'permission_function' => 'addUnit',
                'permission_description' => 'Can add units in the system'
            ],
            [
                'permission_name' => 'Read Unit',
                'permission_function' => 'readUnit',
                'permission_description' => 'Can view units in the system'
            ],
            [
                'permission_name' => 'Update Unit',
                'permission_function' => 'updateUnit',
                'permission_description' => 'Can update units in the system'
            ],
            [
                'permission_name' => 'Delete Unit',
                'permission_function' => 'deleteUnit',
                'permission_description' => 'Can delete units in the system'
            ],
            [
                'permission_name' => 'Add Unit Offering',
                'permission_function' => 'addUnitOffering',
                'permission_description' => 'Can add unit offerings in the system'
            ],
            [
                'permission_name' => 'Read Unit Offering',
                'permission_function' => 'readUnitOffering',
                'permission_description' => 'Can view unit offerings in the system'
            ],
            [
                'permission_name' => 'Update Unit Offering',
                'permission_function' => 'updateUnitOffering',
                'permission_description' => 'Can update unit offerings in the system'
            ],
            [
                'permission_name' => 'Delete Unit Offering',
                'permission_function' => 'deleteUnitOffering',
                'permission_description' => 'Can delete unit offerings in the system'
            ],
            [
                'permission_name' => 'Add Learning Outcome',
                'permission_function' => 'addLearningOutcome',
                'permission_description' => 'Can add learning outcomes in the system'
            ],
            [
                'permission_name' => 'Read Learning Outcome',
                'permission_function' => 'readLearningOutcome',
                'permission_description' => 'Can read learning outcomes in the system'
            ],
            [
                'permission_name' => 'Update Learning Outcome',
                'permission_function' => 'updateLearningOutcome',
                'permission_description' => 'Can update learning outcomes in the system'
            ],
            [
                'permission_name' => 'Delete Learning Outcome',
                'permission_function' => 'deleteLearningOutcome',
                'permission_description' => 'Can delete learning outcomes in the system'
            ],
            [
                'permission_name' => 'Add Major',
                'permission_function' => 'addMajor',
                'permission_description' => 'Can add majors in the system'
            ],
            [
                'permission_name' => 'Read Major',
                'permission_function' => 'readMajor',
                'permission_description' => 'Can read majors in the system'
            ],
            [
                'permission_name' => 'Update Major',
                'permission_function' => 'updateMajor',
                'permission_description' => 'Can update majors in the system'
            ],
            [
                'permission_name' => 'Delete Major',
                'permission_function' => 'deleteMajor',
                'permission_description' => 'Can delete majors in the system'
            ],
            [
                'permission_name' => 'Add Location',
                'permission_function' => 'addLocation',
                'permission_description' => 'Can add locations in the system'
            ],
            [
                'permission_name' => 'Read Location',
                'permission_function' => 'readLocation',
                'permission_description' => 'Can read locations in the system'
            ],
            [
                'permission_name' => 'Update Location',
                'permission_function' => 'updateLocation',
                'permission_description' => 'Can update locations in the system'
            ],
            [
                'permission_name' => 'Delete Location',
                'permission_function' => 'deleteLocation',
                'permission_description' => 'Can delete locations in the system'
            ],
            [
                'permission_name' => 'Add Competency',
                'permission_function' => 'addCompetency',
                'permission_description' => 'Can add competencies in the system'
            ],
            [
                'permission_name' => 'Read Competency',
                'permission_function' => 'readCompetency',
                'permission_description' => 'Can read competencies in the system'
            ],
            [
                'permission_name' => 'Update Competency',
                'permission_function' => 'updateCompetency',
                'permission_description' => 'Can update competencies in the system'
            ],
            [
                'permission_name' => 'Delete Competency',
                'permission_function' => 'deleteCompetency',
                'permission_description' => 'Can delete competencies in the system'
            ],
            [
                'permission_name' => 'Add Role',
                'permission_function' => 'addRole',
                'permission_description' => 'Can add roles in the system'
            ],
            [
                'permission_name' => 'Read Role',
                'permission_function' => 'readRole',
                'permission_description' => 'Can read roles in the system'
            ],
            [
                'permission_name' => 'Update Role',
                'permission_function' => 'updateRole',
                'permission_description' => 'Can update roles in the system'
            ],
            [
                'permission_name' => 'Delete Role',
                'permission_function' => 'deleteRole',
                'permission_description' => 'Can delete roles in the system'
            ],
            [
                'permission_name' => 'Add Permission',
                'permission_function' => 'addPermission',
                'permission_description' => 'Can add permissions in the system'
            ],
            [
                'permission_name' => 'Read Permission',
                'permission_function' => 'readPermission',
                'permission_description' => 'Can read permissions in the system'
            ],
            [
                'permission_name' => 'Update Permission',
                'permission_function' => 'updatePermission',
                'permission_description' => 'Can update permissions in the system'
            ],
            [
                'permission_name' => 'Delete Permission',
                'permission_function' => 'deletePermission',
                'permission_description' => 'Can delete permissions in the system'
            ],
            [
                'permission_name' => 'Add Staff',
                'permission_function' => 'addStaff',
                'permission_description' => 'Can add staff in the system'
            ],
            [
                'permission_name' => 'Read Staff',
                'permission_function' => 'readStaff',
                'permission_description' => 'Can read staff in the system'
            ],
            [
                'permission_name' => 'Update Staff',
                'permission_function' => 'updateStaff',
                'permission_description' => 'Can update staff in the system'
            ],
            [
                'permission_name' => 'Delete Staff',
                'permission_function' => 'deleteStaff',
                'permission_description' => 'Can delete staff in the system'
            ],
        ];

        foreach($permissions as $permission){
            Permission::create($permission);
        }
    }
}
