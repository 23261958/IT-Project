<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(CourseSeeder::class);
        $this->call(UnitSeeder::class);
        $this->call(StaffSeeder::class);
        $this->call(LocationSeeder::class);
        $this->call(MajorSeeder::class);
        $this->call(UnitOfferingSeeder::class);
        $this->call(LearningOutcomeSeeder::class);
        $this->call(CompetencySeeder::class);
        $this->call(UserSeeder::class);
        $this->call(LocationUnitOfferingSeeder::class);
        $this->call(CompetencyLearningOutcomeSeeder::class);
        $this->call(LearningOutcomeLearningOutcomeSeeder::class);
        $this->call(RoleSeeder::class);
        $this->call(RoleUserSeeder::class);
        $this->call(PermissionSeeder::class);
        $this->call(RolePermissionSeeder::class);
        $this->call(CourseUnitSeeder::class);
        $this->call(MajorUnitSeeder::class);


    }
}
