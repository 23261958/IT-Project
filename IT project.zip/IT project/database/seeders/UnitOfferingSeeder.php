<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\UnitOffering;

class UnitOfferingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $unit_offerings = [
            [
                'unit_id' => '1',
                'study_period' => 'Session 1',
                'year' => '2021',
                'unit_assessor_id' => '1',
            ],
            [
                'unit_id' => '1',
                'study_period' => 'Session 2',
                'year' => '2021',
                'unit_assessor_id' => '2',
                'lecturer_1_id' => '1',
            ],
        ];

        foreach($unit_offerings as $unit_offering){
            UnitOffering::create($unit_offering);
        }
    }
}
