<?php

namespace Database\Seeders;

use App\Models\Major;
use Illuminate\Database\Seeder;



class MajorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $majors = [
            [
                'course_id'=> '1',
                'name'=> 'Civil Major 1'
            ],

            [
                'course_id'=> '1',
                'name'=> 'Civil Major 2'
            ],

            [
                'course_id'=> '2',
                'name'=> 'Software Development'
            ],

            [
                'course_id'=> '2',
                'name'=> 'Network Engineering'
            ]


        ];

        foreach($majors as $major){
            Major::create($major);
        }
    }
}
