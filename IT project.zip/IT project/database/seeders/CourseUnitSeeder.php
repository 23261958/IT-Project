<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CourseUnitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $course_unit = [
            [
                'course_id' => '1',
                'unit_id' => '1'
                //'type' => 'Associate Degree'

            ],
            [
                'course_id' => '1',
                'unit_id' => '2'
                //'type' => 'Associate Degree'

            ],

        ];

        foreach($course_unit as $link){
            DB::insert('INSERT INTO course_unit (course_id, unit_id) VALUES (?, ?)', [$link['course_id'], $link['unit_id']]);
        }
    }
}
