<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $roles = [
            [
                'role_name' => 'Administrator'

            ],
            [
                'role_name' => 'Unit Designer'

            ],
            [
                'role_name' => 'Staff Manager'

            ],

        ];

        foreach($roles as $role){
            Role::create($role);
        }
    }
}
