<?php

namespace Database\Seeders;

use App\Models\LearningOutcome;
use Illuminate\Database\Seeder;

class LearningOutcomeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $learning_outcomes = [
            [
                'code' => '123',
                'description' => 'Civil Learning outcome Test 1',
                'type' => 'Course',
                'course_id' => '1',



            ],

            [
                'code' => '234',
                'description' => 'Civil Learning outcome Test 2',
                'type' => 'Unit',
                'unit_id' => '2',




            ],

            [
                'code' => '345',
                'description' => 'InfoTech Learning outcome Test 1',
                'type' => 'Major',
                'major_id' => '3'
            ]


        ];

        foreach($learning_outcomes as $learning_outcome){
            LearningOutcome::create($learning_outcome);
        }
    }
}
