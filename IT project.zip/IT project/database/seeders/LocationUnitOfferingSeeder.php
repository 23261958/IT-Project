<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LocationUnitOfferingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $locationUnits = [
            [
                'location_id'=> '1',
                'unit_offering_id'=> '1'
            ],

            [
                'location_id'=> '2',
                'unit_offering_id'=> '1'
            ],

            [
                'location_id'=> '3',
                'unit_offering_id'=> '1'
            ],

            [
                'location_id'=> '2',
                'unit_offering_id'=> '2'
            ],

            [
                'location_id'=> '3',
                'unit_offering_id'=> '2'
            ],
        ];

        foreach($locationUnits as $link){
            DB::insert('INSERT INTO location_unit_offering (location_id, unit_offering_id) VALUES (?, ?)', [$link['location_id'], $link['unit_offering_id']]);
        }
    }
}
