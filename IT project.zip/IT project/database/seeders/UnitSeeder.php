<?php

namespace Database\Seeders;

use App\Models\Unit;
use Illuminate\Database\Seeder;

class UnitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $units = [
            [
                'unit_code' => 'CIVL1001',
                'unit_name' => 'Civil Construction Unit 1',
                'credit_points' => '6',
                'aqf_level' => '5'

            ],
            [
                'unit_code' => 'CIVL1002',
                'unit_name' => 'Civil Construction Unit 2',
                'credit_points' => '12',
                'aqf_level' => '7'
            ],
            [
                'unit_code' => 'CSCI1001',
                'unit_name' => 'InfoTech Unit 1',
                'credit_points' => '12',
                'aqf_level' => '7'
            ]
        ];

        foreach($units as $unit){
            Unit::create($unit);
        }
    }
}
