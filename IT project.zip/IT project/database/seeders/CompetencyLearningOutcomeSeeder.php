<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CompetencyLearningOutcomeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $competencyLearningOutcomes = [
            [
                'competency_id'=> '1',
                'learning_outcome_id'=> '1',
                'proficiency'=> '2'
            ],
            [
                'competency_id'=> '1',
                'learning_outcome_id'=> '2',
                'proficiency'=> '1'
            ],
            [
                'competency_id'=> '2',
                'learning_outcome_id'=> '3',
                'proficiency'=> null
            ],
            [
                'competency_id'=> '3',
                'learning_outcome_id'=> '1',
                'proficiency'=> null
            ]
        ];

        foreach($competencyLearningOutcomes as $link) {
            DB::insert('INSERT INTO competency_learning_outcome (competency_id, learning_outcome_id, proficiency) VALUES (?, ?, ?)', [$link['competency_id'], $link['learning_outcome_id'], $link['proficiency']]);
        }
    }
}
