<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    use HasFactory;

    public function learningOutcomes() {
        return $this->hasMany(LearningOutcome::class);
    }

    public function units() {
        return $this->belongsToMany(Unit::class);
    }

    public function majors() {
        return $this->hasMany(Major::class);
    }
}
