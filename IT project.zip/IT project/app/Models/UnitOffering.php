<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UnitOffering extends Model
{
    use HasFactory;

    public function unit() {
        return $this->belongsTo(Unit::class);
    }

    public function unitAssessor() {
        return $this->belongsTo(Staff::class, 'unit_assessor_id');
    }

    public function lecturer1() {
        return $this->belongsTo(Staff::class, 'lecturer_1_id');
    }

    public function lecturer2() {
        return $this->belongsTo(Staff::class, 'lecturer_2_id');
    }

    public function locations() {
        return $this->belongsToMany(Location::class);
    }
}


