<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LearningOutcome extends Model
{
    use HasFactory;

    public function course() {
        return $this->belongsTo(Course::class);
    }

    public function unit() {
        return $this->belongsTo(Unit::class);
    }

    public function major() {
        return $this->belongsTo(Major::class);
    }

    public function competencies() {
        return $this->belongsToMany(Competency::class);
    }

    public function learningOutcomes1() {
        return $this->belongsToMany(LearningOutcome::class, 'learning_outcome_learning_outcome', 'learning_outcome_1_id', 'learning_outcome_2_id');
    }

    public function learningOutcomes2() {
        return $this->belongsToMany(LearningOutcome::class, 'learning_outcome_learning_outcome', 'learning_outcome_2_id', 'learning_outcome_1_id');
    }

}
