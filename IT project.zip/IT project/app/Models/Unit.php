<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Unit extends Model
{
    use HasFactory;

    public function courses() {
        return $this->belongsToMany(Course::class);
    }

    public function majors() {
        return $this->belongsToMany(Major::class);
    }

    public function unitOfferings() {
        return $this->hasMany(UnitOffering::class);
    }

    public function learningOutcomes() {
        return $this->hasMany(LearningOutcome::class);
    }

}
