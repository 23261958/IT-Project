<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use HasFactory;

    public function unitAssessors() {
        return $this->hasMany(UnitOffering::class, 'unit_assessor_id');
    }

    public function lecturer1s() {
        return $this->hasMany(UnitOffering::class, 'lecturer_1_id');
    }

    public function lecturer2s() {
        return $this->hasMany(UnitOffering::class, 'lecturer_2_id');
    }
}
