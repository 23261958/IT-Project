<?php

namespace App\Http\Controllers;

use App\Models\Location;
use App\Models\UnitOffering;
use App\Models\Unit;
use App\Models\Staff;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class UnitOfferingController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // this method was called from the following route
        // Route::get('/unit_offerings', [UnitOfferingController::class, 'index'])->name('unit_offerings');

        // get all unit_offerings
        $unit_offerings = UnitOffering::get();

        // pass all unit_offerings and return the unit_offerings.index view
        return view('unit_offerings.index', compact('unit_offerings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/unit_offerings/create', [UnitOfferingController::class, 'create'])->name('unit_offerings.create');

        // get all units
        $units = Unit::get();

        // get all staff
        $staff = Staff::get();

        $locations = Location::get();

        // pass all units and staff and return the unit_offerings.create view
        return view('unit_offerings.create', compact(['units', 'staff', 'locations']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/unit_offerings', [UnitOfferingController::class, 'store']);

        $request->validate([
            'unit_id' => 'required|exists:App\Models\Unit,id',
            'study_period' => 'required|max:191',
            'year' => 'required',
            'unit_assessor_id' => 'required|exists:App\Models\Staff,id'
        ]);
        // create a new unit_offering
        $unit_offering = new UnitOffering();

        // set the fields in the unit_offering using the request input from the form on the unit_offerings.create view
        // note that the input key matches the field ids on the form
        $unit_offering->unit_id = $request->input('unit_id');
        $unit_offering->study_period = $request->input('study_period');
        $unit_offering->year = $request->input('year');
        $unit_offering->unit_assessor_id = $request->input('unit_assessor_id');
        $unit_offering->lecturer_1_id = $request->input('lecturer_1_id');
        $unit_offering->lecturer_2_id = $request->input('lecturer_2_id');

        // persist the unit_offering
        $status=$unit_offering->save();

        // add locations
        $locations = $request->input('locations');
        if($locations) {
            foreach ($locations as $location) {
                DB::insert("INSERT INTO location_unit_offering (location_id, unit_offering_id) VALUES (?, ?)", [$location, $unit_offering->id]);
            }
        }

        $links = Session::get('links'); // getting an array from the session
        unset($links[0]); // remove post request URL from $links, we do not want to check this URL
        // check where the user navigated from so we can redirect back to them
        foreach($links as $link) {
            if($link == "/unit_offerings") { // navigated from unit offerings index page
                return redirect(route('unitOfferings'))->with('alertAdd', $status);
            } else if($link == "/dashboard") { // navigated from dashboard
                return redirect(route('dashboard'))->with('alertAdd', $status);
            }
        }
        // default redirect to the dashboard if no matches found
        return redirect(route('dashboard'))->with('alertAdd', $status);    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\UnitOffering $unit_offering
     * @return \Illuminate\Http\Response
     */
    public function show(UnitOffering $unit_offering)
    {
        // this method was called from the following route
        // Route::get('/unit_offerings/{unit_offering}/show', [UnitOfferingController::class, 'show'])->name('unit_offerings.show');

        // pass the unit_offering to show and return the unit_offerings.show view
        return view('unit_offerings.show', compact('unit_offering'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\UnitOffering $unit_offering
     * @return \Illuminate\Http\Response
     */
    public function edit(UnitOffering $unit_offering)
    {
        // this method was called from the following route
        // Route::get('/unit_offerings/{unit_offering}/edit', [UnitOfferingController::class, 'edit'])->name('unit_offerings.edit');

        // get all units
        $units = Unit::get();

        // get all staff
        $staff = Staff::get();

        $locations = Location::get();

        // pass the unit_offering to edit and return the unit_offerings.edit view
        return view('unit_offerings.edit', compact(['unit_offering', 'units', 'staff', 'locations']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\UnitOffering $unit_offering
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UnitOffering $unit_offering)
    {
        // this method was called from the following route
        // Route::put('/unit_offerings/{unit_offering}', [UnitOfferingController::class, 'update'])->name('unit_offerings.update');

        $request->validate([
            'unit_id' => 'required|exists:App\Models\Unit,id',
            'study_period' => 'required|max:191',
            'year' => 'required',
            'unit_assessor_id' => 'required|exists:App\Models\Staff,id'
        ]);
        // update the fields in the unit_offering using the request input from the form on the unit_offerings.edit view
        // note that the input key matches the field ids on the form
        $unit_offering->unit_id = $request->input('unit_id');
        $unit_offering->study_period = $request->input('study_period');
        $unit_offering->year = $request->input('year');
        $unit_offering->unit_assessor_id = $request->input('unit_assessor_id');
        $unit_offering->lecturer_1_id = $request->input('lecturer_1_id');
        $unit_offering->lecturer_2_id = $request->input('lecturer_2_id');

        // persist the unit_offering
        $status=$unit_offering->save();

        // change locations
        DB::table('location_unit_offering')->where('unit_offering_id', '=', $unit_offering->id)->delete();
        $locations = $request->input('locations');
        if($locations) {
            foreach ($locations as $location) {
                DB::insert("INSERT INTO location_unit_offering (location_id, unit_offering_id) VALUES (?, ?)", [$location, $unit_offering->id]);
            }
        }

        // redirect to the route named unit_offerings - Route::get('/unit_offerings', [UnitOfferingController::class, 'index'])->name('unit_offerings');
        return redirect(route('unit_offerings'))->with('alertEdit', $status);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\UnitOffering $unit_offering
     * @return \Illuminate\Http\Response
     */
    public function destroy(UnitOffering $unit_offering)
    {
        // this method was called from the following route
        // Route::delete('/unit_offerings/{unit_offering}/destroy', [UnitOfferingController::class, 'destroy'])->name('unit_offerings.destroy');

        // delete the unit_offering
        $status=$unit_offering->delete();

        // redirect to the route named unit_offerings - Route::get('/unit_offerings', [UnitOfferingController::class, 'index'])->name('unit_offerings');
        return redirect(route('unit_offerings'))->with('alertDelete', $status);
    }
}
