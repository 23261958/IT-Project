<?php

namespace App\Http\Controllers;

use App\Models\Location;
use App\Models\Unit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;


class UnitController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // this method was called from the following route
        // Route::get('/units', [UnitController::class, 'index'])->name('units');

        // get all units
        $units = Unit::get();

        // pass all units and return the units.index view
        return view('units.index', compact('units'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/units/create', [UnitController::class, 'create'])->name('units.create');


        // return the units.create view
        return view('units.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/units', [UnitController::class, 'store']);
        $request->validate([
            'unit_code' => 'required|unique:units,unit_code|size:8',
            'unit_name' => 'required|max:191',
            'credit_points' => 'required|numeric|min:1',
            'aqf_level' => 'required|numeric|min:1|max:10'
        ]);

        // create a new unit
        $unit = new Unit();

        // set the fields in the unit using the request input from the form on the units.create view
        // note that the input key matches the field ids on the form
        $unit->unit_code = $request->input('unit_code');
        $unit->unit_name = $request->input('unit_name');
        $unit->credit_points = $request->input('credit_points');
        $unit->aqf_level = $request->input('aqf_level');


        // persist the unit
        $status=$unit->save();

        $links = Session::get('links'); // getting an array from the session
        unset($links[0]); // remove post request URL from $links, we do not want to check this URL
        // check where the user navigated from so we can redirect back to them
        foreach($links as $link) {
            if($link == "/units") { // navigated from units index page
                return redirect(route('courses'))->with('alertAdd', $status);
            } else if($link == "/dashboard") { // navigated from dashboard
                return redirect(route('dashboard'))->with('alertAdd', $status);
            }
        }
        // default redirect to the dashboard if no matches found
        return redirect(route('dashboard'))->with('alertAdd', $status);

    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\Unit $unit
     * @return \Illuminate\Http\Response
     */
    public function show(Unit $unit)
    {
        // this method was called from the following route
        // Route::get('/units/{unit}/show', [UnitController::class, 'show'])->name('units.show');

        // pass the unit to show and return the units.show view
        return view('units.show', compact('unit'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\Unit $unit
     * @return \Illuminate\Http\Response
     */
    public function edit(Unit $unit)
    {
        // this method was called from the following route
        // Route::get('/units/{unit}/edit', [UnitController::class, 'edit'])->name('units.edit');



        // pass the unit to edit and return the units.edit view
        return view('units.edit', compact(['unit']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Unit $unit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Unit $unit)
    {
        // this method was called from the following route
        // Route::put('/units/{unit}', [UnitController::class, 'update'])->name('units.update');
        $request->validate([
            'unit_code' => 'required|unique:units,unit_code,'.$unit->unit_code.',unit_code|size:8',
            'unit_name' => 'required|max:191',
            'credit_points' => 'required|numeric|min:1',
            'aqf_level' => 'required|numeric|min:1|max:10'
        ]);

        // update the fields in the unit using the request input from the form on the units.edit view
        // note that the input key matches the field ids on the form
        $unit->unit_code = $request->input('unit_code');
        $unit->unit_name = $request->input('unit_name');
        $unit->credit_points = $request->input('credit_points');
        $unit->aqf_level = $request->input('aqf_level');

        // persist the unit
        $status=$unit->save();


        // redirect to the route named units - Route::get('/units', [UnitController::class, 'index'])->name('units');
        return redirect(route('units'))->with('alertEdit',$status);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\Unit $unit
     * @return \Illuminate\Http\Response
     */
    public function destroy(Unit $unit)
    {
        // this method was called from the following route
        // Route::delete('/units/{unit}/destroy', [UnitController::class, 'destroy'])->name('units.destroy');

        // delete the unit
        $status=$unit->delete();

        // redirect to the route named units - Route::get('/units', [UnitController::class, 'index'])->name('units');
        return redirect(route('units'))->with('alertDelete',$status);
    }
}
