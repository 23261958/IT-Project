<?php

namespace App\Http\Controllers;

use App\Models\Location;
use App\Models\UnitOffering;
use App\Models\Unit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;


class LocationController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // this method was called from the following route
        // Route::get('/location', [LocationController::class, 'index'])->name('location');

        // get all location
        $locations = Location::get();

        // pass all location and return the location.index view
        return view('locations.index', compact('locations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/location/create', [LocationController::class, 'create'])->name('location.create');

        // return the location.create view
        return view('locations.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/location', [LocationController::class, 'store']);
        $request->validate([
            'name'=> 'required|max:191'
        ]);
        // create a new location
        $location = new Location();

        // set the fields in the location using the request input from the form on the location.create view
        // note that the input key matches the field ids on the form
        $location->name = $request->input('name');

        // persist the location
        $status=$location->save();
        // add locations

        return redirect(route('locations'))->with('alertAdd',$status); // will redirect 2 links back


    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\Location $location
     * @return \Illuminate\Http\Response
     */
    public function show(Location $location)
    {
        // this method was called from the following route
        // Route::get('/location/{location}/show', [locationController::class, 'show'])->name('location.show');

        // pass the location to show and return the location.show view
        return view('locations.show', compact('location'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\Location $location
     * @return \Illuminate\Http\Response
     */
    public function edit(Location $location)
    {
        // this method was called from the following route
        // Route::get('/location/{location}/edit', [LocationController::class, 'edit'])->name('location.edit');

        // pass the location to edit and return the location.edit view
        return view('locations.edit', compact(['location']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Location $location
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Location $location)
    {
        // this method was called from the following route
        // Route::put('/location/{location}', [LocationController::class, 'update'])->name('location.update');
        $request->validate([
            'name'=> 'required|max:191'
        ]);
        // update the fields in the location using the request input from the form on the location.edit view
        // note that the input key matches the field ids on the form
        $location->name = $request->input('name');

        // persist the location
        $status=$location->save();

        // redirect to the route named location - Route::get('/location', [LocationController::class, 'index'])->name('location');
        return redirect(route('locations'))->with('alertEdit',$status);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\location $location
     * @return \Illuminate\Http\Response
     */
    public function destroy(location $location)
    {
        // this method was called from the following route
        // Route::delete('/location/{location}/destroy', [LocationController::class, 'destroy'])->name('location.destroy');

        // delete the location
        $status=$location->delete();

        // redirect to the route named location - Route::get('/location', [locationController::class, 'index'])->name('location');
        return redirect(route('locations'))->with('alertDelete',$status);
    }
}
