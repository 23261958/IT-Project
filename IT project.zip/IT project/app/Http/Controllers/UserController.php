<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // this method was called from the following route
        // Route::get('/users', [UserController::class, 'index'])->name('users');

        // get all users
        $users = User::get();

        // pass all users and return the users.index view
        return view('users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/users/create', [UserController::class, 'create'])->name('users.create');

        $roles = Role::get();
        // return the users.create view
        return view('users.create', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/users', [UserController::class, 'store']);

        $request->validate([
            'name' => 'required|max:191',
            'email' => 'required|max:191|email:rfc,dns|confirmed',
            'password' => 'required|max:191|regex:/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/|confirmed',
        ]);

        // create a new user
        $user = new User();

        // set the fields in the user using the request input from the form on the users.create view
        // note that the input key matches the field ids on the form
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->password = Hash:: make($request->input('password'));

        // persist the user
        $status=$user->save();

//        // persist the unit
//        $user->save();

        // add roles
        $newUser = User::where('email', $user->email)->first();
        $roles = $request->input('roles');
        if($roles) {
            foreach ($roles as $role) {
                DB::insert("INSERT INTO role_user (role_id, user_id) VALUES (?, ?)", [$role, $newUser->id]);
            }
        }


        // redirect to the route named users - Route::get('/users', [UserController::class, 'index'])->name('users');
        return redirect(route('users'))->with('alertAdd',$status);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        // this method was called from the following route
        // Route::get('/users/{user}/show', [UserController::class, 'show'])->name('users.show');

        // pass the user to show and return the users.show view
        return view('users.show', compact('user'));
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function showAccount(User $user)
    {
        // this method was called from the following route
        // Route::get('/users/{user}/show', [UserController::class, 'show'])->name('users.show');

        // pass the user to show and return the users.show view
        return view('users.accounts.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        // this method was called from the following route
        // Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('users.edit');

        $roles=Role::get();
        // pass the user to edit and return the users.edit view
        return view('users.edit', compact(['user','roles']));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function editAccount(User $user)
    {
        // this method was called from the following route
        // Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('users.edit');

        // pass the user to edit and return the users.edit view
        return view('users.accounts.edit', compact('user'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function updateAccount(Request $request, User $user)
    {
        // this method was called from the following route
        // Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('users.edit');
        $request->validate([
            'name' => 'required|max:191',
            'email' => 'required|max:191|email:rfc,dns|confirmed'
        ]);
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $status = $user->save();

        // pass the user to edit and return the users.edit view
        return redirect(route('users.accounts.show', compact('user')))->with('alertAccount',$status);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function changePassword(User $user)
    {
        // this method was called from the following route
        // Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('users.edit');

        // pass the user to edit and return the users.edit view
        return view('users.accounts.password', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function updatePassword(Request $request, User $user)
    {
        // this method was called from the following route
        // Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('users.edit');
        if (!Hash::check($request->input('currentPassword'), Auth::user()->password)) {
            return back()->withErrors(['currentPassword'=>'Current password does not match.']);
        }
        $request->validate([
            'currentPassword'=> 'required',
            'password'=> 'required|max:191|regex:/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/|confirmed'
        ]);
        $user->password = Hash::make($request->input('password'));
        $status = $user->save();
        // pass the user to edit and return the users.edit view
        return redirect(route('users.accounts.show', compact('user')))->with('alertPassword',$status);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        // this method was called from the following route
        // Route::put('/users/{user}', [UserController::class, 'update'])->name('users.update');
        if ($request->input('password') == '') {
            $request->validate([
                'name' => 'required|max:191',
                'email' => 'required|max:191|email:rfc,dns|confirmed'
            ]);
        } else {
            $request->validate([
                'name' => 'required|max:191',
                'email' => 'required|max:191|email:rfc,dns|confirmed',
                'password' => 'required|max:191|regex:/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/|confirmed'
            ]);
        }


        // update the fields in the user using the request input from the form on the users.edit view
        // note that the input key matches the field ids on the form
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        if ($request->input('password') != "") {
            $user->password = Hash::make($request->input('password'));
        }

        // persist the user
        $status=$user->save();

        // change roles
        DB::table('role_user')->where('user_id', '=', $user->id)->delete();
        $roles = $request->input('roles');
        if($roles) {
            foreach ($roles as $role) {
                DB::insert("INSERT INTO role_user (role_id, user_id) VALUES (?, ?)", [$role, $user->id]);
            }
        }

        return redirect(route('users'))->with('alertEdit',$status);


    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        // this method was called from the following route
        // Route::delete('/users/{user}/destroy', [UserController::class, 'destroy'])->name('users.destroy');

        // delete the user
        $status=$user->delete();

        // redirect to the route named users - Route::get('/users', [UserController::class, 'index'])->name('users');
        return redirect(route('users'))->with('alertDelete',$status);
    }
}
