<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Unit;
use App\Models\Major;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class MajorController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //get all majors

        $majors = Major::get();

        //pass all majors and return the majors.index view
        return view('majors.index', compact('majors'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        //get all courses
        $courses = Course::get();

        //get all units
        $units = Unit::get();

        //pass all majors and return the majors.create view
        return view('majors.create', compact(['courses']));

        //pass all majors and return the majors.create view
        return view('majors.create', compact('units'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'course_id' => 'required|exists:App\Models\Course,id',
            'name' => 'required|max:191'
        ]);


        //create a new major
        $major = new Major();

        //set the fields in the major using the request input from the form on the majors.create view
        $major->course_id = $request->input('course_id');
        $major->name = $request->input('name');

        //persist the major
        $status=$major->save();

        // add units
        $newMajor = Major::where('name', $major->name)->first();
        $units = $request->input('units');
        if($units) {
            foreach ($units as $unit) {
                DB::insert("INSERT INTO major_unit (unit_id, major_id) VALUES (?, ?)", [$unit, $newMajor->id]);
            }
        }



        $links = Session::get('links'); // getting an array from the session
        unset($links[0]); // remove post request URL from $links, we do not want to check this URL
        // check where the user navigated from so we can redirect back to them
        foreach($links as $link) {
            if($link == "/majors") { // navigated from majors index page
                return redirect(route('courses'))->with('alertAdd', $status);
            } else if($link == "/dashboard") { // navigated from dashboard
                return redirect(route('dashboard'))->with('alertAdd', $status);
            }
        }
        // default redirect to the dashboard if no matches found
        return redirect(route('dashboard'))->with('alertAdd', $status);



    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Major  $major
     * @return \Illuminate\Http\Response
     */
    public function show(Major $major)
    {
        //pass the major to show and return the major.show view

        return view('majors.show', compact('major'));
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Major  $major
     * @return \Illuminate\Http\Response
     */
    public function edit(Major $major)
    {
        //get all courses
        $courses = Course::get();
        $majors = Major::get();

        $units = Unit::get();

        //pass the majors to edit and return the majors.edit view
        return view('majors.edit', compact(['major', 'courses', 'units']));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Major  $major
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Major $major)
    {
        //the course_id is required in updating the major
        $request->validate([
            'course_id' => 'required|exists:App\Models\Course,id',
            'name' => 'required|max:191'
        ]);

        // update the fields in the major using the request input from the form on the units.edit view
        $major->course_id = $request->input('course_id');
        $major->name = $request->input('name');

        //persist the major
        $status=$major->save();

        // change units
        DB::table('major_unit')->where('major_id', '=', $major->id)->delete();
        $units = $request->input('units');
        if($units) {
            foreach ($units as $unit) {
                DB::insert("INSERT INTO major_unit (unit_id, major_id) VALUES (?, ?)", [$unit, $major->id]);
            }
        }

        //redirect to the route majors
        return redirect(route('majors'))->with('alertEdit',$status);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Major  $major
     * @return \Illuminate\Http\Response
     */
    public function destroy(Major $major)
    {
        //delete the major
        $status=$major->delete();

        //redirect to the route majors
        return redirect(route('majors'))->with('alertDelete',$status);

    }
}
