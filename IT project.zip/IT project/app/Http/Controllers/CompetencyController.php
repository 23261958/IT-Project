<?php

namespace App\Http\Controllers;

use App\Models\Competency;
use App\Models\LearningOutcome;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Response;
use Illuminate\Support\Str;


class CompetencyController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        // this method was called from the following route
        // Route::get('/competencies', [CompetencyController::class, 'index'])->name('competencies');

        // get all competencies
        $competencies = Competency::get();

        // pass all competencies and return the competencies.index view
        return view('competencies.index', compact('competencies'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/competencies/create', [CompetencyController::class, 'create'])->name('competencies.create');
        // return the competencies.create view
        return view('competencies.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/competencies', [CompetencyController::class, 'store']);

        // create a new Competency
        $request->validate([

            'description' => 'required|max:191',
            'type' => 'required|max:191',

        ]);

        $competency = new Competency();

        // set the fields in the permission using the request input from the form on the location.create view
        // note that the input key matches the field ids on the form
        $competency->description = $request->input('description');
        $competency->type = $request->input('type');

        // persist the competency
        $status=$competency->save();

        return redirect(route('competencies'))->with('alertAdd',$status);
    }

    /**
     * Display the specified resource.
     *
     * @param Competency $competency
     * @return Response
     */
    public function show(Competency $competency)
    {
        // this method was called from the following route
        // Route::get('/$competencies/{$competency}/show', [CompetencyController::class, 'show'])->name('$competencies.show');

        // pass the competency to show and return the competency.show view
        return view('competencies.show', compact('competency'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Competency $competency
     * @return Response
     */
    public function edit(Competency $competency)
    {
        // this method was called from the following route
        // Route::get('/$competencies/{$competency}/edit', [CompetencyController::class, 'edit'])->name('$competency.edit');
        // pass the competency to edit and return the competency.edit view
        return view('competencies.edit', compact(['competency']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Competency $competency
     * @return Response
     */
    public function update(Request $request, Competency $competency)
    {
        $request->validate([


            'description' => 'required|max:191',
            'type' => 'required|max:191',


        ]);

        // update the fields in the competencies using the request input from the form on the competencies.edit view
        // note that the input key matches the field ids on the form

        $competency->description = $request->input('description');
        $competency->type = $request->input('type');


        // persist the competency
        $status=$competency->save();

        // redirect to the route named competencies - Route::get('/competencies', [competencyController::class, 'index'])->name('competencies');
        return redirect(route('competencies'))->with('alertEdit',$status);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Competency $competency
     * @return Response
     */
    public function destroy(Competency $competency)
    {
        // this method was called from the following route
        // Route::delete('/competencies/{competency}/destroy', [competencyController::class, 'destroy'])->name('competencies.destroy');

        // delete the competency
        $status=$competency->delete();

        // redirect to the route named competencies - Route::get('/competencies', [competencyController::class, 'index'])->name('competencies');
        return redirect(route('competencies'))->with('alertDelete',$status);
    }
}
