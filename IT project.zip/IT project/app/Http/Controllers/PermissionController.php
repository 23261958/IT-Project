<?php

namespace App\Http\Controllers;

use App\Models\Permission;
use Illuminate\Http\Request;


class PermissionController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

            // this method was called from the following route
            // Route::get('/roles', [RoleController::class, 'index'])->name('roles');

            // get all roles
            $permissions = Permission::get();

            // pass all roles and return the roles.index view
            return view('permissions.index', compact('permissions'));


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/permissions/create', [PermissionController::class, 'create'])->name('permissions.create');

        // return the roles.create view
        return view('permissions.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/permissions', [PermissionController::class, 'store']);

        // create a new Permission
        $request->validate([

            'permission_name' => 'required|max:191',
            'permission_function' => 'required|max:191',
            'permission_description' => 'required|max:191',


        ]);

        $permission = new permission();

        // set the fields in the permission using the request input from the form on the Permission.create view
        // note that the input key matches the field ids on the form
        $permission->permission_name = $request->input('permission_name');
        $permission->permission_function = $request->input('permission_function');
        $permission->permission_description = $request->input('permission_description');


        // persist the Permission
        $status=$permission->save();

        // redirect to the route named permission - Route::get('/$permission', [PermissionController::class, 'index'])->name('$permission');
        return redirect(route('permissions'))->with('alertAdd',$status);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Permission  $permission
     * @return \Illuminate\Http\Response
     */
    public function show(Permission $permission)
    {
        // this method was called from the following route
        // Route::get('/permissions/{permission}/show', [PermissionController::class, 'show'])->name('permissions.show');

        // pass the permission to show and return the permission.show view
        return view('permissions.show', compact('permission'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Permission  $permission
     * @return \Illuminate\Http\Response
     */
    public function edit(Permission $permission)
    {
        // this method was called from the following route
        // Route::get('/permissions/{permission}/edit', [PermissionController::class, 'edit'])->name('permissions.edit');

        // pass the role to edit and return the roles.edit view
        return view('permissions.edit', compact('permission'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Permission  $permission
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Permission $permission)
    {
        $request->validate([


            'permission_name' => 'required|max:191',
            'permission_function' => 'required|max:191',
            'permission_description' => 'required|max:191',

        ]);

        // update the fields in the permission using the request input from the form on the permissions.edit view
        // note that the input key matches the field ids on the form

        $permission->permission_name = $request->input('permission_name');
        $permission->permission_function = $request->input('permission_function');
        $permission->permission_description = $request->input('permission_description');


        // persist the permission
        $status=$permission->save();

        // redirect to the route named permissions - Route::get('/permissions', [permissionController::class, 'index'])->name('permissions');
        return redirect(route('permissions'))->with('alertEdit',$status);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Permission  $permission
     * @return \Illuminate\Http\Response
     */
    public function destroy(Permission $permission)
    {
        // this method was called from the following route
        // Route::delete('/permissions/{permission}/destroy', [permissionController::class, 'destroy'])->name('permissions.destroy');
        // delete the permission
        $status=$permission->delete();

        // redirect to the route named roles - Route::get('/permissions', [permissionController::class, 'index'])->name('permissions');
        return redirect(route('permissions'))->with('alertDelete',$status);
    }
}
