<?php

namespace App\Http\Controllers;

use App\Models\Staff;
use App\Models\Location;
use App\Models\UnitOffering;
use App\Models\Unit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;


class StaffController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // this method was called from the following route
        // Route::get('/staff', [StaffController::class, 'index'])->name('staff');
        $staff = Staff::get();
        // pass all staff and return the staff.index view
        return view('staff.index', compact('staff'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/staff/create', [StaffController::class, 'create'])->name('staff.create');

        $locations = Location::get();

        // return the staff.create view
        return view('staff.create', compact(['locations']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/staff', [StaffController::class, 'store']);

        $request->validate([
            'first_name' => 'required|max:191',
            'last_name' => 'required|max:191',
            'staff_role' => 'required|max:191',
            'email' => 'required|max:191|email:rfc,dns',
            'phone' => 'required|digits_between:10,10',
            'campus' => 'required',
            'end_contract' => 'required|date|after:today',
            'proposed_extension' => 'max:191'
        ]);
        // create a new staff
        $staff = new Staff();

        // set the fields in the staff using the request input from the form on the staff.create view
        // note that the input key matches the field ids on the form
        $staff->first_name = $request->input('first_name');
        $staff->last_name = $request->input('last_name');
        $staff->staff_role = $request->input('staff_role');
        $staff->email = $request->input('email');
        $staff->phone = $request->input('phone');
        $staff->campus = $request->input('campus');
        $staff->end_contract = $request->input('end_contract');
        $staff->proposed_extension = $request->input('proposed_extension');


        // persist the staff
        $status=$staff->save();

        $links = Session::get('links'); // getting an array from the session
        unset($links[0]); // remove post request URL from $links, we do not want to check this URL
        // check where the user navigated from so we can redirect back to them
        foreach($links as $link) {
            if($link == "/staff") { // navigated from staff index page
                return redirect(route('courses'))->with('alertAdd', $status);
            } else if($link == "/dashboard") { // navigated from dashboard
                return redirect(route('dashboard'))->with('alertAdd', $status);
            }
        }
        // default redirect to the dashboard if no matches found
        return redirect(route('dashboard'))->with('alertAdd', $status);
    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\Staff $staff
     * @return \Illuminate\Http\Response
     */
    public function show(Staff $staff)
    {
        // this method was called from the following route
        // Route::get('/staff/{staff}/show', [staffController::class, 'show'])->name('staff.show');

        // pass the staff to show and return the staff.show view
        return view('staff.show', compact('staff'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\Staff $staff
     * @return \Illuminate\Http\Response
     */
    public function edit(Staff $staff)
    {
        // this method was called from the following route
        // Route::get('/staff/{staff}/edit', [StaffController::class, 'edit'])->name('staff.edit');

        $locations = Location::get();

        // pass the staff to edit and return the staff.edit view
        return view('staff.edit',  compact(['staff','locations']));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Staff $staff
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Staff $staff)
    {
        // this method was called from the following route
        // Route::put('/staff/{staff}', [StaffController::class, 'update'])->name('staff.update');
        $request->validate([
            'first_name' => 'required|max:191',
            'last_name' => 'required|max:191',
            'staff_role' => 'required|max:191',
            'email' => 'required|max:191|email:rfc,dns',
            'phone' => 'required|digits_between:10,10',
            'campus' => 'required',
            'end_contract' => 'required|date|after:today',
            'proposed_extension' => 'max:191'
        ]);
        // update the fields in the staff using the request input from the form on the staff.edit view
        // note that the input key matches the field ids on the form
        $staff->first_name = $request->input('first_name');
        $staff->last_name = $request->input('last_name');
        $staff->staff_role = $request->input('staff_role');
        $staff->email = $request->input('email');
        $staff->phone = $request->input('phone');
        $staff->campus = $request->input('campus');
        $staff->end_contract = $request->input('end_contract');
        $staff->proposed_extension = $request->input('proposed_extension');


        // persist the staff
        $status = $staff->save();

        // redirect to the route named staff - Route::get('/staff', [StaffController::class, 'index'])->name('staff');
        return redirect(route('staff'))->with('alertEdit', $status);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\staff $staff
     * @return \Illuminate\Http\Response
     */
    public function destroy(staff $staff)
    {
        // this method was called from the following route
        // Route::delete('/staff/{staff}/destroy', [StaffController::class, 'destroy'])->name('staff.destroy');

        // delete the staff
        $status = $staff->delete();

        // redirect to the route named staff - Route::get('/staff', [staffController::class, 'index'])->name('staff');
        return redirect(route('staff'))->with('alertDelete', $status);
    }
}
