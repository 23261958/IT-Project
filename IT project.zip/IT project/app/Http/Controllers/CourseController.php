<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Major;
use App\Models\Unit;
use App\Models\LearningOutcome;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CourseController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // this method was called from the following route
        // Route::get('/courses', [CourseController::class, 'index'])->name('courses');

        // get all courses
        $courses = Course::get();

        // pass all courses and return the courses.index view
        return view('courses.index', compact('courses'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/courses/create', [CourseController::class, 'create'])->name('courses.create');

        $units = Unit::get();
        // return the courses.create view
        return view('courses.create', compact('units'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/courses', [CourseController::class, 'store']);

        $request->validate([
            'course_code' => 'required|unique:courses,course_code|numeric|digits:7',
            'course_title' => 'required|max:191',
            'course_type' => 'required|max:191',
            'credit_points' => 'required|numeric',
            'aqf_level' => 'required|numeric|digits:1',
            //'deleted' => 'max:255',

        ]);

        // create a new course
        $course = new Course();

        // set the fields in the course using the request input from the form on the courses.create view
        // note that the input key matches the field ids on the form
        $course->course_code = $request->input('course_code');
        $course->course_title = $request->input('course_title');
        $course->course_type = $request->input('course_type');
        $course->credit_points = $request->input('credit_points');
        $course->aqf_level = $request->input('aqf_level');
        //$course->deleted = $request->input('deleted');

        // persist the course
        //$course->save();
        $status=$course->save();

        // add units
        $newCourse = Course::where('course_title', $course->course_title)->first();
        $units = $request->input('units');
        if($units) {
            foreach ($units as $unit) {
                if ($unit) {
                    $unitID = Str::before($unit,'_');
                    $unitType = Str::after($unit,'_');
                    DB::insert("INSERT INTO course_unit (unit_id, course_id, type) VALUES (?, ?, ?)", [$unitID, $newCourse->id, $unitType]);
                }
            }
        }

        $links = Session::get('links'); // getting an array from the session
        unset($links[0]); // remove post request URL from $links, we do not want to check this URL
        // check where the user navigated from so we can redirect back to them
        foreach($links as $link) {
            if($link == "/courses") { // navigated from courses index page
                return redirect(route('courses'))->with('alertAdd', $status);
            } else if($link == "/dashboard") { // navigated from dashboard
                return redirect(route('dashboard'))->with('alertAdd', $status);
            }
        }
        // default redirect to the dashboard if no matches found
        return redirect(route('dashboard'))->with('alertAdd', $status);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function show(Course $course)
    {
        // this method was called from the following route
        // Route::get('/courses/{course}/show', [CourseController::class, 'show'])->name('courses.show');

        // pass the course to show and return the courses.show view
        return view('courses.show', compact('course'));
    }




    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function edit(Course $course)
    {
        // this method was called from the following route
        // Route::get('/courses/{course}/edit', [CourseController::class, 'edit'])->name('courses.edit');

        $units = Unit::get();
        // pass the course to edit and return the courses.edit view
        return view('courses.edit', compact(['course','units']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Course $course)
    {
        // this method was called from the following route
        // Route::put('/courses/{course}', [CourseController::class, 'update'])->name('courses.update');
        $request->validate([
            'course_code' => 'required|unique:courses,course_code,'.$course->course_code.',course_code|numeric|digits:7',
            'course_title' => 'required|max:191',
            'course_type' => 'required|max:191',
            'credit_points' => 'required|numeric',
            'aqf_level' => 'required|numeric|digits:1',
            //'deleted' => 'max:255',

        ]);

        // update the fields in the course using the request input from the form on the courses.edit view
        // note that the input key matches the field ids on the form
        $course->course_code = $request->input('course_code');
        $course->course_title = $request->input('course_title');
        $course->course_type = $request->input('course_type');
        $course->credit_points = $request->input('credit_points');
        $course->aqf_level = $request->input('aqf_level');
        //$course->deleted = $request->input('deleted');

        // persist the course
        //$course->save();
        $status=$course->save();

        // change units
        DB::table('course_unit')->where('course_id', '=', $course->id)->delete();
        $units = $request->input('units');
        if($units) {
            foreach ($units as $unit) {
                DB::insert("INSERT INTO course_unit (unit_id, course_id) VALUES (?, ?)", [$unit, $course->id]);
            }
        }


        // redirect to the route named courses - Route::get('/courses', [CourseController::class, 'index'])->name('courses');
        //return redirect(route('courses'));
        return redirect(route('courses'))->with('alertEdit',$status);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function destroy(Course $course)
    {
        // this method was called from the following route
        // Route::delete('/courses/{course}/destroy', [CourseController::class, 'destroy'])->name('courses.destroy');

        // delete the course
        //$course->delete();
        $status=$course->delete();

        // redirect to the route named courses - Route::get('/courses', [CourseController::class, 'index'])->name('courses');
        //return redirect(route('courses'));
        return redirect(route('courses'))->with('alertDelete',$status);
    }
}
