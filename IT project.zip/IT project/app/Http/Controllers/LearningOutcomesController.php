<?php

namespace App\Http\Controllers;

use App\Models\Unit;
use Illuminate\Http\Request;
use App\Models\LearningOutcome;
use App\Models\Competency;
use App\Models\Course;
use App\Models\Major;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;




class LearningOutcomesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // this method was called from the following route
        // Route::get('/learningOutcomes', [LearningOutcomesController::class, 'index'])->name('learningOutcomes');

        // get all learning outcomes
        $learning = LearningOutcome::get();

        // pass all learning outcomes and return the learning_outcomes.index view
        return view('learning_outcomes.index', compact('learning'));
    }

        /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/learningOutcomes/create', [LearningOutcomesController::class, 'create'])->name('learningOutcomes.create');

        // get all units
        $units = Unit::get();

        // get all courses
        $courses = Course::get();

        // get all majors
        $majors = Major::get();




        // return the learning_outcomes.create view
        return view('learning_outcomes.create', compact(['units', 'courses', 'majors']));
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createLODashboard()
    {
        // this method was called from the following route
        // Route::get('/learningOutcomes/create', [LearningOutcomesController::class, 'create'])->name('learningOutcomes.create');

        // get all units
        $units = Unit::get();

        // get all courses
        $courses = Course::get();

        // get all majors
        $majors = Major::get();



        // return the learning_outcomes.create view
        return view('learning_outcomes.dashboard_create', compact(['units', 'courses', 'majors']));
    }





    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/learningOutcomes', [LearningOutcomesController::class, 'store']);

        $request->validate([

            'code' => 'required|max:191',
            'description' => 'required|max:191',
            'type' => 'required|max:191',


        ]);

        // create a new learning outcome
        $learning = new LearningOutcome();

        // set the fields in the course using the request input from the form on the courses.create view
        // note that the input key matches the field ids on the form
        $learning->code = $request->input('code');
        $learning->description = $request->input('description');
        $learning->type = $request->input('type');
        $learning->unit_id = $request->input('unit_id');
        $learning->course_id = $request->input('course_id');
        $learning->major_id = $request->input('major_id');


        // persist the learning outcome
        $status = $learning->save();


            // redirect to the route named learningOutcomes - Route::get('/learningOutcomes', [LearningOutcomesController::class, 'index'])->name('learningOutcomes');
            return redirect(route('learningOutcomes'))->with('alertAdd', $status);
        }


    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\LearningOutcome  $learningOutcomes
     * @return \Illuminate\Http\Response
     */
    public function edit(LearningOutcome $learningOutcome)
    {
        // this method was called from the following route
        // Route::get('/learningOutcomes/{learningOutcome}/edit', [LearningOutcomesController::class, 'edit'])->name('learningOutcomes.edit');
        // get all units
        $units = Unit::get();

        // get all courses
        $courses = Course::get();

        // get all majors
        $majors = Major::get();



        // return the learning_outcomes.create view
        return view('learning_outcomes.edit', compact(['learningOutcome', 'units', 'courses', 'majors']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\LearningOutcome  $learningOutcomes
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LearningOutcome $learningOutcome)
    {
        // this method was called from the following route
        //Route::put('/learningOutcomes/{learningOutcome}', [LearningOutcomesController::class, 'update'])->name('learningOutcomes.update');
        $request->validate([

            'code' => 'required|max:191',
            'description' => 'required|max:255',
            'type' => 'required|max:191',


        ]);

        // update the fields in the learning outcomes using the request input from the form on the learning_outcomes.edit view
        // note that the input key matches the field ids on the form
        $learningOutcome->code = $request->input('code');
        $learningOutcome->description = $request->input('description');
        $learningOutcome->type = $request->input('type');
        $learningOutcome->unit_id = $request->input('unit_id');
        $learningOutcome->course_id = $request->input('course_id');
        $learningOutcome->major_id = $request->input('major_id');


        // persist the learning outcome
        $status=$learningOutcome->save();



        // redirect to the route named learningOutcomes - Route::get('/learningOutcomes', [LearningOutcomesController::class, 'index'])->name('learningOutcomes');
        return redirect(route('learningOutcomes'))->with('alertEdit',$status);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\LearningOutcome  $learningOutcomes
     * @return \Illuminate\Http\Response
     */
    public function show(LearningOutcome $learningOutcome)
    {
        // this method was called from the following route
        // Route::get('/learningOutcomes/{learningOutcome}/show', [LearningOutcomesController::class, 'show'])->name('learningOutcomes.show');

        // pass the learning outcome to show and return the learning_outcomes.show view
        return view('learning_outcomes.show', compact('learningOutcome'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\LearningOutcome  $learningOutcomes
     * @return \Illuminate\Http\Response
     */
    public function destroy(LearningOutcome $learningOutcome)
    {
        // this method was called from the following route
        // Route::delete('/learningOutcomes/{learningOutcome}/destroy', [LearningOutcomesController::class, 'destroy'])->name('learningOutcomes.destroy');

        // delete the learning outcome
        $status=$learningOutcome->delete();

        // redirect to the route named learningOutcomes - Route::get('/learningOutcomes', [LearningOutcomesController::class, 'index'])->name('learningOutcomes');
        return redirect(route('learningOutcomes'))->with('alertDelete',$status);
    }

}
