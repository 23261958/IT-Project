<?php

namespace App\Http\Controllers;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class RoleController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // this method was called from the following route
        // Route::get('/roles', [RoleController::class, 'index'])->name('roles');

        // get all roles
        $roles = Role::get();

        // pass all roles and return the roles.index view
        return view('roles.index', compact('roles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // this method was called from the following route
        // Route::get('/roles/create', [RoleController::class, 'create'])->name('roles.create');
        $permissions = Permission::get();
        // return the roles.create view
        return view('roles.create', compact('permissions'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // this method was called from the following route
        // Route::post('/roles', [RoleController::class, 'store']);

        $request->validate([
            'role_name' => 'required|max:191',

        ]);

        // create a new role
        $role = new Role();

        // set the fields in the role using the request input from the form on the roles.create view
        // note that the input key matches the field ids on the form
        $role->role_name = $request->input('role_name');


        // persist the role
        $status=$role->save();

        $newRole = Role::where('role_name', $role->role_name)->first();
        $permissions = $request->input('permissions');
        if($permissions) {
            foreach ($permissions as $permission) {
                DB::insert("INSERT INTO permission_role (permission_id, role_id) VALUES (?, ?)", [$permission,$newRole ->id]);
            }

        }

        // redirect to the route named roles - Route::get('/roles', [RoleController::class, 'index'])->name('roles');
        return redirect(route('roles'))->with('alertAdd',$status);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function show(Role $role)
    {
        // this method was called from the following route
        // Route::get('/roles/{role}/show', [RoleController::class, 'show'])->name('roles.show');

        // pass the role to show and return the roles.show view
        return view('roles.show', compact('role'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function edit(Role $role)
    {
        // this method was called from the following route
        // Route::get('/roles/{role}/edit', [RoleController::class, 'edit'])->name('roles.edit');
        $permissions=Permission::get();

        // pass the role to edit and return the roles.edit view
        return view('roles.edit', compact(['role','permissions']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Role $role)
    {
        // this method was called from the following route
        // Route::put('/roles/{role}', [RoleController::class, 'update'])->name('roles.update');
        $request->validate([
            'role_name' => 'required|max:191',

        ]);

        // update the fields in the role using the request input from the form on the roles.edit view
        // note that the input key matches the field ids on the form
        $role->role_name = $request->input('role_name');


        // persist the role
        $status=$role->save();

        DB::table('permission_role')->where('role_id', '=', $role->id)->delete();
        $permissions = $request->input('permissions');
        if ($permissions) {
            foreach ($permissions as $permission) {
                DB::insert("INSERT INTO permission_role (permission_id, role_id) VALUES (?, ?)", [$permission, $role->id]);
            }
        }
            // redirect to the route named roles - Route::get('/roles', [RoleController::class, 'index'])->name('roles');
        return redirect(route('roles'))->with('alertEdit',$status);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function destroy(Role $role)
    {
        // this method was called from the following route
        // Route::delete('/roles/{role}/destroy', [RoleController::class, 'destroy'])->name('roles.destroy');

        // delete the role
        $status=$role->delete();

        // redirect to the route named roles - Route::get('/roles', [RoleController::class, 'index'])->name('roles');
        return redirect(route('roles'))->with('alertDelete',$status);
    }
}
