<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class CollectRoutes
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $links = Session::has('links') ? Session::get('links') : array();
        $currentLink = $_SERVER['REQUEST_URI']; // getting current URL like 'category/books/'
        Str::lower($currentLink);
        $currentLink = Str::replace('coursedesigner/', '', $currentLink);
        $currentLink = Str::replace('public/', '', $currentLink);
        array_unshift($links, $currentLink); // putting it in the beginning of an array
        Session::flash('links', $links); // saving an array to the session
        return $next($request);
    }
}
