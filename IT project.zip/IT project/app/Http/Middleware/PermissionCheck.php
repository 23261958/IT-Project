<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PermissionCheck
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     * @param $permission
     * @return mixed
     */
    public function handle(Request $request, Closure $next, $permission)
    {
        if (Auth::user()) {
            if (Auth::user()->permissions()->contains('permission_function', $permission)) {
                return $next($request);
            }
        } else {
            return redirect(route('login'));
        }

        return abort('403', 'Access denied. Contact administrator.');
    }
}
