<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\LocationController;
use App\Http\Controllers\UnitOfferingController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\LearningOutcomesController;
use App\Http\Controllers\MajorController;
use App\Http\Controllers\CompetencyController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\PermissionController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/login');
});

//Route::get('/login', [LoginController::class, 'index']);
/*Route::get('/', function () {
    return view('Hello All new new');
});
/* --------------- dashboard ----------------*/

// get unit designer dashboard
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard')->middleware('allowed:readUnit');

/* --------------- Units ----------------*/

// get all units and display them
//return index.blade.php
Route::get('/units', [UnitController::class, 'index'])->name('units')->middleware('allowed:readUnit');

// show a form to create a new unit
//return create.blade.php
Route::get('/units/create', [UnitController::class, 'create'])->name('units.create')->middleware('allowed:addUnit');

// save the new unit you created in the form above. Notice that this has the same endpoint as
// the first units route but it is a POST. We do not need a name for this route as there is no
// view associated with it
Route::post('/units', [UnitController::class, 'store'])->middleware('allowed:addUnit');

// view a specific unit
//return show.blade.php
Route::get('/units/{unit}/show', [UnitController::class, 'show'])->name('units.show')->middleware('allowed:readUnit');


// show a form to edit a unit
//return edit.blade.php
Route::get('/units/{unit}/edit', [UnitController::class, 'edit'])->name('units.edit')->middleware('allowed:updateUnit');

// update the unit you just edited in the form above.
Route::put('/units/{unit}', [UnitController::class, 'update'])->name('units.update')->middleware('allowed:updateUnit');

// delete a unit
Route::delete('/units/{unit}/destroy', [UnitController::class, 'destroy'])->name('units.destroy')->middleware('allowed:deleteUnit');

/* -------------- Staff ------------- */

// all staff
Route::get('/staff', [StaffController::class, 'index'])->name('staff')->middleware('allowed:readStaff');

// specific staff
Route::get('/staff/{staff}/show', [StaffController::class, 'show'])->name('staff.show')->middleware('allowed:readStaff');

// create new staff form
Route::get('/staff/create', [StaffController::class, 'create'])->name('staff.create')->middleware('allowed:addStaff');

// submit create staff form
Route::post('/staff', [StaffController::class, 'store'])->middleware('allowed:addStaff');

// edit specific staff form
Route::get('/staff/{staff}/edit', [StaffController::class, 'edit'])->name('staff.edit')->middleware('allowed:updateStaff');

// submit edit staff form
Route::put('/staff/{staff}', [StaffController::class, 'update'])->name('staff.update')->middleware('allowed:updateStaff');

// delete staff
Route::delete('/staff/{staff}/destroy', [StaffController::class, 'destroy'])->name('staff.destroy')->middleware('allowed:deleteStaff');



/* -------------- Location ------------- */

// all locations
Route::get('/locations', [LocationController::class, 'index'])->name('locations')->middleware('allowed:readLocation');

// specific location
Route::get('/locations/{location}/show', [LocationController::class, 'show'])->name('locations.show')->middleware('allowed:readLocation');

// create new location form
Route::get('/locations/create', [LocationController::class, 'create'])->name('locations.create')->middleware('allowed:addLocation');

// submit create location form
Route::post('/locations', [LocationController::class, 'store'])->middleware('allowed:addLocation');

// edit specific location form
Route::get('/locations/{location}/edit', [LocationController::class, 'edit'])->name('locations.edit')->middleware('allowed:updateLocation');

// submit edit location form
Route::put('/locations/{location}', [LocationController::class, 'update'])->name('locations.update')->middleware('allowed:updateLocation');

// delete location
Route::delete('/locations/{location}/destroy', [LocationController::class, 'destroy'])->name('locations.destroy')->middleware('allowed:deleteLocation');



/* -------------- Unit Offering ------------- */

// all unit offerings
Route::get('/unit_offerings', [UnitOfferingController::class, 'index'])->name('unit_offerings')->middleware('allowed:readUnitOffering');

// specific unit offering
Route::get('/unit_offerings/{unit_offering}/show', [UnitOfferingController::class, 'show'])->name('unit_offerings.show')->middleware('allowed:addUnitOffering');

// create new unit offering form
Route::get('/unit_offerings/create', [UnitOfferingController::class, 'create'])->name('unit_offerings.create')->middleware('allowed:addUnitOffering');

// submit create unit offering form
Route::post('/unit_offerings', [UnitOfferingController::class, 'store'])->middleware('allowed:readUnitOffering');

// edit specific unit offering form
Route::get('/unit_offerings/{unit_offering}/edit', [UnitOfferingController::class, 'edit'])->name('unit_offerings.edit')->middleware('allowed:updateUnitOffering');

// submit edit unit offering form
Route::put('/unit_offerings/{unit_offering}', [UnitOfferingController::class, 'update'])->name('unit_offerings.update')->middleware('allowed:updateUnitOffering');

// delete unit offering
Route::delete('/unit_offerings/{unit_offering}/destroy', [UnitOfferingController::class, 'destroy'])->name('unit_offerings.destroy')->middleware('allowed:deleteUnitOffering');


/* --------------- Courses ----------------*/

// get all courses and display them
//return index.blade.php
Route::get('/courses', [CourseController::class, 'index'])->name('courses')->middleware('allowed:readCourse');

// show a form to create a new course
//return create.blade.php
Route::get('/courses/create', [CourseController::class, 'create'])->name('courses.create')->middleware('allowed:addCourse');

// save the new course you created in the form above. Notice that this has the same endpoint as
// the first course route but it is a POST. We do not need a name for this route as there is no
// view associated with it
Route::post('/courses', [CourseController::class, 'store'])->middleware('allowed:addCourse');

// view a specific course
//return show.blade.php
Route::get('/courses/{course}/show', [CourseController::class, 'show'])->name('courses.show')->middleware('allowed:readCourse');




// show a form to edit a course
//return edit.blade.php
Route::get('/courses/{course}/edit', [CourseController::class, 'edit'])->name('courses.edit')->middleware('allowed:updateCourse');

// update the course you just edited in the form above.
Route::put('/courses/{course}', [CourseController::class, 'update'])->name('courses.update')->middleware('allowed:updateCourse');

// delete a course
Route::delete('/courses/{course}/destroy', [CourseController::class, 'destroy'])->name('courses.destroy')->middleware('allowed:deleteCourse');

/* --------------- Majors ----------------*/

// all majors
Route::get('/majors', [MajorController::class, 'index'])->name('majors')->middleware('allowed:readMajor');

// specific major
Route::get('/majors/{major}/show', [MajorController::class, 'show'])->name('majors.show')->middleware('allowed:readMajor');


// create new major form
Route::get('/majors/create', [MajorController::class, 'create'])->name('majors.create')->middleware('allowed:addMajor');

// submit create major form
Route::post('/majors', [MajorController::class, 'store'])->middleware('allowed:addMajor');

// edit specific major form
Route::get('/majors/{major}/edit', [MajorController::class, 'edit'])->name('majors.edit')->middleware('allowed:updateMajor');

// submit edit major form
Route::put('/majors/{major}', [MajorController::class, 'update'])->name('majors.update')->middleware('allowed:updateMajor');

// delete major
Route::delete('/majors/{major}/destroy', [MajorController::class, 'destroy'])->name('majors.destroy')->middleware('allowed:deleteMajor');





/* --------------- Learning Outcomes ----------------*/

// get all LearningOutcomesController and display them
//return index.blade.php
Route::get('/learningOutcomes', [LearningOutcomesController::class, 'index'])->name('learningOutcomes')->middleware('allowed:readLearningOutcome');

// show a form to create a new LearningOutcomesController
//return create.blade.php
Route::get('/learningOutcomes/create', [LearningOutcomesController::class, 'create'])->name('learningOutcomes.create')->middleware('allowed:addLearningOutcome');




// save the new LearningOutcomesController you created in the form above. Notice that this has the same endpoint as
// the first LearningOutcomesController route but it is a POST. We do not need a name for this route as there is no
// view associated with it
Route::post('/learningOutcomes', [LearningOutcomesController::class, 'store'])->middleware('allowed:addLearningOutcome');

// view a specific LearningOutcomesController
//return show.blade.php
Route::get('/learningOutcomes/{learningOutcome}/show', [LearningOutcomesController::class, 'show'])->name('learningOutcomes.show')->middleware('allowed:readLearningOutcome');

// show a form to edit a LearningOutcomesController
//return edit.blade.php
Route::get('/learningOutcomes/{learningOutcome}/edit', [LearningOutcomesController::class, 'edit'])->name('learningOutcomes.edit')->middleware('allowed:updateLearningOutcome');

// update the LearningOutcomesController you just edited in the form above.
Route::put('/learningOutcomes/{learningOutcome}', [LearningOutcomesController::class, 'update'])->name('learningOutcomes.update')->middleware('allowed:updateLearningOutcome');

// delete a LearningOutcomesController
Route::delete('/learningOutcomes/{learningOutcome}/destroy', [LearningOutcomesController::class, 'destroy'])->name('learningOutcomes.destroy')->middleware('allowed:deleteLearningOutcome');

/* -------------- Competencies ------------- */

// all competencies
Route::get('/competencies', [CompetencyController::class, 'index'])->name('competencies')->middleware('allowed:readCompetency');

//return show.blade.php
Route::get('/competencies/{competency}/show', [CompetencyController::class, 'show'])->name('competencies.show')->middleware('allowed:readCompetency');

//return create.blade.php
Route::get('/competencies/create', [CompetencyController::class, 'create'])->name('competencies.create')->middleware('allowed:addCompetency');

// submit create competency form
Route::post('/competencies', [CompetencyController::class, 'store'])->middleware('allowed:addCompetency');

// edit specific competency
// return edit.blade.php
Route::get('/competencies/{competency}/edit', [CompetencyController::class, 'edit'])->name('competencies.edit')->middleware('allowed:updateCompetency');

// submit edit competency form
Route::put('/competencies/{competency}', [CompetencyController::class, 'update'])->name('competencies.update')->middleware('allowed:updateCompetency');

// delete competency
Route::delete('/competencies/{competency}/destroy', [CompetencyController::class, 'destroy'])->name('competencies.destroy')->middleware('allowed:deleteCompetency');



/* --------------- Users ----------------*/

// get all users and display them
//return index.blade.php
Route::get('/users', [UserController::class, 'index'])->name('users')->middleware('allowed:readUser');

// show a form to create a new user
//return create.blade.php
Route::get('/users/create', [UserController::class, 'create'])->name('users.create')->middleware('allowed:addUser');

// save the new user you created in the form above. Notice that this has the same endpoint as
// the first user route but it is a POST. We do not need a name for this route as there is no
// view associated with it
Route::post('/users', [UserController::class, 'store'])->middleware('allowed:addUser');

// view a specific user
//return show.blade.php
Route::get('/users/{user}/show', [UserController::class, 'show'])->name('users.show')->middleware('allowed:readUser');

// show a form to edit a user
//return edit.blade.php
Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('users.edit')->middleware('allowed:updateUser');

// update the user you just edited in the form above.
Route::put('/users/{user}/update', [UserController::class, 'update'])->name('users.update')->middleware('allowed:updateUser');

// delete a user
Route::delete('/users/{user}/destroy', [UserController::class, 'destroy'])->name('users.destroy')->middleware('allowed:deleteUser');


/* --------------- Accounts ----------------*/

// view the account logged in
//return account.show.blade.php
Route::get('/users/accounts/{user}/showAccount', [UserController::class, 'showAccount'])->name('users.accounts.show');

//return account.edit.blade.php
Route::get('/users/accounts/{user}/editAccount', [UserController::class, 'editAccount'])->name('users.accounts.edit');

//return account.edit.blade.php
Route::put('/users/accounts/{user}/editAccount', [UserController::class, 'updateAccount'])->name('users.accounts.updateAccount');

// return account.password.blade.php
Route::get('/users/accounts/{user}/changePassword', [UserController::class, 'changePassword'])->name('users.accounts.password');

// return account.password.blade.php
Route::put('/users/accounts/{user}/changePassword', [UserController::class, 'updatePassword'])->name('users.accounts.updatePassword');



/* --------------- Roles ----------------*/

// get all roles and display them
//return index.blade.php
Route::get('/roles', [RoleController::class, 'index'])->name('roles')->middleware('allowed:readRole');

// show a form to create a new role
//return create.blade.php
Route::get('/roles/create', [RoleController::class, 'create'])->name('roles.create')->middleware('allowed:addRole');

// save the new role you created in the form above. Notice that this has the same endpoint as
// the first role route but it is a POST. We do not need a name for this route as there is no
// view associated with it
Route::post('/roles', [RoleController::class, 'store'])->middleware('allowed:addRole');

// view a specific role
//return show.blade.php
Route::get('/roles/{role}/show', [RoleController::class, 'show'])->name('roles.show')->middleware('allowed:readRole');

// show a form to edit a role
//return edit.blade.php
Route::get('/roles/{role}/edit', [RoleController::class, 'edit'])->name('roles.edit')->middleware('allowed:updateRole');

// update the role you just edited in the form above.
Route::put('/roles/{role}', [RoleController::class, 'update'])->name('roles.update')->middleware('allowed:updateRole');

// delete a role
Route::delete('/roles/{role}/destroy', [RoleController::class, 'destroy'])->name('roles.destroy')->middleware('allowed:deleteRole');


Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

/* --------------- permissions ----------------*/



// get all permissions and display them
//return index.blade.php
Route::get('/permissions', [PermissionController::class, 'index'])->name('permissions')->middleware('allowed:readPermission');

// show a form to create a new permission
//return create.blade.php
Route::get('/permissions/create', [PermissionController::class, 'create'])->name('permissions.create')->middleware('allowed:addPermission');

// save the new permission you created in the form above. Notice that this has the same endpoint as
// the first permission route but it is a POST. We do not need a name for this route as there is no
// view associated with it
Route::post('/permissions', [PermissionController::class, 'store'])->middleware('allowed:addPermission');

// view a specific permission
//return show.blade.php
Route::get('/permissions/{permission}/show', [PermissionController::class, 'show'])->name('permissions.show')->middleware('allowed:readPermission');

// show a form to edit a permission
//return edit.blade.php
Route::get('/permissions/{permission}/edit', [PermissionController::class, 'edit'])->name('permissions.edit')->middleware('allowed:updatePermission');

// update the permission you just edited in the form above.
Route::put('/permissions/{permission}', [PermissionController::class, 'update'])->name('permissions.update')->middleware('allowed:updatePermission');

// delete a role
Route::delete('/permissions/{permission}/destroy', [PermissionController::class, 'destroy'])->name('permissions.destroy')->middleware('allowed:deletePermission');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
