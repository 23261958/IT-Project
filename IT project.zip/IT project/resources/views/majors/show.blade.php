@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')
    <h2>Major - {{$major->name}}</h2>
    <a href="{{route("majors")}}" class="btn btn-danger my-2">Back</a>
    <div class="card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Details</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th>Major Id</th>
                    <th>Course Id</th>
                    <th>Name</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the major id, course id and major name -->
                    <td>{{$major->id}}</td>
                    <td>{{$major->course_id}}</td>
                    <td>{{$major->name}}</td>

                    <td>
                        <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                        <form role="form" method="POST" action="{{ route('majors.destroy', $major) }}">
                            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                        @csrf
                        <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                        @method('DELETE')

                        <!-- Bootstrap button to edit the major. Once again, technically this does not need to be in the form. However I added it here
                        otherwise it would not be inline with the delete button. The link matches the name of the following route:
                        Route::get('/majors/{major}/edit', [MajorController::class, 'edit'])->name('majors.edit');
                        this route calls the edit function in MajorController and it will add the id of the unit to the wildcard in the
                        endpoint-->
                            <a href="{{ route('majors.edit', $major) }}" class="btn btn-warning"
                               role="button">Edit</a>

                            <!-- Bootstrap button to delete the major. This button submits the form. If you look at the form action above you will see that the action calls
                            Route::delete('/majors/{major}/destroy', [MajorController::class, 'destroy'])->name('majors.destroy');
                            and it will add the id of the major to the wildcard in the endpoint-->
                            <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this major?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>

                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Courses</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if($major->course)
                <h5>Courses</h5>
                <table id="example1" class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Course ID</th>
                        <th>Course Code</th>
                        <th>Course Title</th>
                        <th>Course Type</th>
                        <th>Credit Points</th>
                        <th>AQF Level</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <!-- show the course id, course code, course title and course type -->
                            <td>{{$major->course->id}}</td>
                            <td>{{$major->course->course_code}}</td>
                            <td>{{$major->course->course_title}}</td>
                            <td>{{$major->course->course_type}}</td>
                            <td>{{$major->course->credit_points}}</td>
                            <td>{{$major->course->aqf_level}}</td>
                            <td>
                                <!-- Bootstrap button to show the course -->
                                <a href="{{ route('courses.show', $major->course) }}" class="btn btn-success"
                                   role="button">Show</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            @else
                No course found.
            @endif
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Units</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if (count($major->units) == 0)
                No units found.
            @elseif (count($major->units) > 0)
                <table id="example1" class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Unit ID</th>
                        <th>Unit Code</th>
                        <th>Unit Name</th>
                        <th>Credit Points</th>
                        <th>AQF Level</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($major->units as $unit)
                        <tr>
                            <!-- show the unit id, unit code and unit name -->
                            <td>{{$unit->id}}</td>
                            <td>{{$unit->unit_code}}</td>
                            <td>{{$unit->unit_name}}</td>
                            <td>{{$unit->credit_points}}</td>
                            <td>{{$unit->aqf_level}}</td>
                            <td>
                            <!-- Bootstrap button to show the units -->
                                <a href="{{ route('units.show', $unit) }}" class="btn btn-success"
                                   role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            @endif
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Learning Outcomes</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if (count($major->learningOutcomes) == 0)
                No learning outcomes found.
            @elseif (count($major->learningOutcomes) > 0)
                <table id="example1" class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Learning Outcome ID</th>
                        <th>Learning Outcome Code</th>
                        <th>Description</th>
                        <th>Type</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($major->learningOutcomes as $learningOutcome)
                        <tr>
                            <!-- show the learning outcome id, learning outcome code, and description -->
                            <td>{{$learningOutcome->id}}</td>
                            <td>{{$learningOutcome->code}}</td>
                            <td>{{$learningOutcome->description}}</td>
                            <td>{{$learningOutcome->type}}</td>
                            <td>
                                <!-- Bootstrap button to show the learning outcome -->
                                <a href="{{ route('learningOutcomes.show', $learningOutcome) }}" class="btn btn-success"
                                   role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            @endif
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Add Learning Outcome</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <!-- /.card-header -->

            <!-- form start - notice it is a POST form as we are posting data. The action of the form is the following route:
             Route::post('/staff', [StaffController::class, 'store']);
             This calls the store method of the StaffController to store our new staff -->
            <form role="form" method="POST" action="{{ route('learningOutcomes') }}">

                <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                @csrf
                <div class="card-body">
                    <div class="form-group">
                        <label for="code">Learning Outcome Code</label>
                        <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                        You must have these so that when we post the data we can get it from the request.
                        Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                         -->
                        <input type="text" maxlength="191" class="form-control" name="code" id="code" placeholder="Enter the Learning Outcome Code..." value="{{old('code')}}" required>
                        @error('code')
                        <p class="danger">{{$errors->first('code')}}</p>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                        You must have these so that when we post the data we can get it from the request.
                        Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                         -->
                        <input type="text" maxlength="191" class="form-control" name="description" id="description" placeholder="Enter the Description..." value="{{old('description')}}" required>
                        @error('description')
                        <p class="text-danger">{{$errors->first('description')}}</p>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="type">Type</label>
                        <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                        You must have these so that when we post the data we can get it from the request.
                        Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                         -->
                        <select class="form-control" name="type" id="type" value="Major" required>
                            <option value="Major">Major</option>
                        </select>

                    </div>
                    <div class="form-group" id="major_div">
                        <label for="major_id">Major</label>
                        <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                        You must have these so that when we post the data we can get it from the request.
                        Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                         -->

                        <select class="form-control" id="major_id" name="major_id" value="{{old('major_id')}}">

                            <option value="{{$major->id}}">{{$major->name}}</option>

                        </select>
                        @error('major_id')
                        <p class="danger">{{$errors->first('major_id')}}</p>
                        @enderror


                    </div>

                    <!-- submit the form -->
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <!-- /.card-body -->
            </form>


        </div>
    </div>

@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
