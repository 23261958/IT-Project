@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">New Unit Offering</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - notice it is a POST form as we are posting data. The action of the form is the following route:
         Route::post('/unit_offerings', [UnitOfferingController::class, 'store']);
         This calls the store method of the UnitOfferingController to store our new unit offering -->
        <form role="form" method="POST" action="{{ route('unit_offerings') }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
            @csrf
            <div class="card-body">
                <div class="form-group">
                    <label for="unit_id">Unit</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->

                    <select id="unit_id" name="unit_id" value="{{old('unit_id')}}">
                        @foreach($units as $unit)
                            <option value="{{$unit->id}}" @if(old('unit_id')==$unit->id)selected @endif>{{$unit->unit_name}}</option>
                        @endforeach
                    </select>
                    @error('unit_id')
                    <p class="danger">{{$errors->first('unit_id')}}</p>
                    @enderror


                </div>
                <div class="form-group">
                    <label for="study_period">Study Period</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="study_period" id="study_period" placeholder="Enter the unit offering's study period..." value="{{old('study_period')}}" required>
                    @error('study_period')
                        <p class="danger">{{$errors->first('study_period')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="year">Year</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="number" class="form-control" name="year" id="year" min="{{date('Y')}}" max="{{date('Y')+10}}" value="{{old('year')}}" required>
                    @error('year')
                        <p class="danger">{{$errors->first('year')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="unit_assessor_id">Unit Assessor</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select id="unit_assessor_id" name="unit_assessor_id" value="{{old('unit_assessor_id')}}">
                        @foreach($staff as $member)
                            <option value="{{$member->id}}" @if(old('unit_assessor_id')==$member->id)selected @endif>{{$member->first_name}} {{$member->last_name}}</option>
                        @endforeach
                    </select>
                    @error('unit_assessor_id')
                        <p class="danger">{{$errors->first('unit_assessor_id')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="lecturer_1_id">Lecturer 1</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select id="lecturer_1_id" name="lecturer_1_id" value="{{old('lecturer_1_id')}}">
                        <option value="">None</option>
                        @foreach($staff as $member)
                            <option value="{{$member->id}}" @if(old('lecturer_1_id')==$member->id)selected @endif>{{$member->first_name}} {{$member->last_name}}</option>
                        @endforeach
                    </select>
                    @error('lecturer_1_id')
                        <p class="danger">{{$errors->first('lecturer_1_id')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="lecturer_2_id">Lecturer 2</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select id="lecturer_2_id" name="lecturer_2_id" value="{{old('lecturer_2_id')}}">
                        <option value="">None</option>
                        @foreach($staff as $member)
                            <option value="{{$member->id}}" @if(old('lecturer_2_id')==$member->id)selected @endif>{{$member->first_name}} {{$member->last_name}}</option>
                        @endforeach
                    </select>
                    @error('lecturer_2_id')
                        <p class="danger">{{$errors->first('lecturer_2_id')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="locations">Locations</label><br>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    @foreach($locations as $location)
                        <span>{{$location->name}}</span>
                        <input type="checkbox" name="locations[]" id="locations{{$location->id}}" value="{{$location->id}}" class="mr-4">
                    @endforeach
                    @error('locations')
                    <p class="text-danger">{{$errors->first('locations')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->



@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
