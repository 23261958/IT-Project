@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Unit Offering - {{$unit_offering->id}}</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - The action of the form is the following route:
         Route::put('/unit_offerings/{unit_offering}', [UnitOfferingController::class, 'update'])->name('unit_offerings.update');
         This calls the update method of the UnitOfferingController to update our unit offering.
         Notice it is a POST form but our route needs a PUT.... -->
        <form role="form" method="POST" action="{{ route('unit_offerings.update', $unit_offering) }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
        @csrf
        <!-- override the POST method with a PUT so we have a put method. We need to do this as browsers
                                do not support PUT via 'HTML form' submission -->
            @method('PUT')
            <div class="card-body">
                <div class="form-group">
                    <label for="unit_id">Unit</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select id="unit_id" name="unit_id" value="{{($errors->any()) ? old('unit_id') : $unit_offering->unit_id}}">
                        @foreach($units as $unit)
                            <option value="{{$unit->id}}" @if(old('unit_id')==$unit->id || $unit_offering->unit_id=="$unit->id" && !$errors->any())selected @endif>{{$unit->unit_name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="study_period">Study Period</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="study_period" id="study_period" placeholder="Enter the unit offering's study period..." value="{{($errors->any()) ? old('study_period') : $unit_offering->study_period}}" required>
                </div>
                <div class="form-group">
                    <label for="year">Year</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="number" class="form-control" name="year" id="year" min="{{date('Y')}}" max="{{date('Y')+10}}" value="{{($errors->any()) ? old('year') : $unit_offering->year}}" required>
                </div>
                <div class="form-group">
                    <label for="unit_assessor_id">Unit Assessor</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select id="unit_assessor_id" name="unit_assessor_id" value="{{($errors->any()) ? old('unit_assessor_id') : $unit_offering->unit_assessor_id}}">
                        @foreach($staff as $member)
                            <option value="{{$member->id}}" @if(old('unit_assessor_id')==$member->id || $unit_offering->unit_assessor_id=="$member->id" && !$errors->any())selected @endif>{{$member->first_name}} {{$member->last_name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="lecturer_1_id">Lecturer 1</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select id="lecturer_1_id" name="lecturer_1_id" value="{{($errors->any()) ? old('lecturer_1_id') : $unit_offering->lecturer_1_id}}">
                        <option value="">None</option>
                        @foreach($staff as $member)
                            <option value="{{$member->id}}" @if(old('lecturer_1_id')==$member->id || $unit_offering->lecturer_1_id=="$member->id" && !$errors->any())selected @endif>{{$member->first_name}} {{$member->last_name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="lecturer_2_id">Lecturer 2</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the unit_offerings table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select id="lecturer_2_id" name="lecturer_2_id" value="{{($errors->any()) ? old('lecturer_2_id') : $unit_offering->lecturer_2_id}}">
                        <option value="">None</option>
                        @foreach($staff as $member)
                            <option value="{{$member->id}}" @if(old('lecturer_2_id')==$member->id || $unit_offering->lecturer_2_id=="$member->id" && !$errors->any())selected @endif>{{$member->first_name}} {{$member->last_name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="locations">Locations</label><br>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    @foreach($locations as $location)
                        <span>{{$location->name}}</span>
                        <input type="checkbox" name="locations[]" id="location{{$location->id}}" value="{{$location->id}}" class="mr-4" @if($unit_offering->locations->contains($location)) checked @endif>
                    @endforeach
                    @error('locations')
                    <p class="text-danger">{{$errors->first('locations')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>

            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
