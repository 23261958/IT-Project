@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')
    <h2>Unit Offering - {{$unit_offering->id}}</h2>
    <a href="{{route("unit_offerings")}}" class="btn btn-danger my-2">Back</a>
    <div class="card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Details</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped mb-4">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th>Unit Offering ID</th>
                    <th>Unit</th>
                    <th>Study Period</th>
                    <th>Year</th>
                    <th>Unit Assessor</th>
                    <th>Lecturer 1</th>
                    <th>Lecturer 2</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the unit offering id, name and code -->
                    <td>{{$unit_offering->id}}</td>
                    <td>{{$unit_offering->unit->unit_name}}</td>
                    <td>{{$unit_offering->study_period}}</td>
                    <td>{{$unit_offering->year}}</td>
                    <td>{{$unit_offering->unitAssessor->first_name}} {{$unit_offering->unitAssessor->last_name}}</td>
                    <td>@if($unit_offering->lecturer1){{$unit_offering->lecturer1->first_name}} {{$unit_offering->lecturer1->last_name}}@endif</td>
                    <td>@if($unit_offering->lecturer2){{$unit_offering->lecturer2->first_name}} {{$unit_offering->lecturer2->last_name}}@endif</td>
                    <td>
                        <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                        <form role="form" method="POST" action="{{ route('unit_offerings.destroy', $unit_offering) }}">
                            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                        @csrf
                        <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                        @method('DELETE')

                           <!-- Bootstrap button to edit the unit offering. Once again, technically this does not need to be in the form. However I added it here
                        otherwise it would not be inline with the delete button. The link matches the name of the following route:
                        Route::get('/unit_offerings/{unit_offering}/edit', [UnitOfferingController::class, 'edit'])->name('unit_offerings.edit');
                        this route calls the edit function in UnitOfferingController and it will add the id of the unit offering to the wildcard in the
                        endpoint-->
                            <a href="{{ route('unit_offerings.edit', $unit_offering) }}" class="btn btn-warning"
                               role="button">Edit</a>

                            <!-- Bootstrap button to delete the unit offering. This button submits the form. If you look at the form action above you will see that the action calls
                            Route::delete('/unit_offerings/{unit_offering}/destroy', [UnitOfferingController::class, 'destroy'])->name('unit_offerings.destroy');
                            and it will add the id of the unit offering to the wildcard in the endpoint-->
                            <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this unit offering?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>

                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Unit</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if($unit_offering->unit)
            <table id="example1" class="table table-bordered table-striped mb-4">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th>Unit ID</th>
                    <th>Unit Code</th>
                    <th>Unit Name</th>
                    <th>Credit Points</th>
                    <th>AQF Level</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the unit id, name and code -->
                    <td>{{$unit_offering->unit->id}}</td>
                    <td>{{$unit_offering->unit->unit_code}}</td>
                    <td>{{$unit_offering->unit->unit_name}}</td>
                    <td>{{$unit_offering->unit->credit_points}}</td>
                    <td>{{$unit_offering->unit->aqf_level}}</td>
                    <td>
                        <a href="{{ route('units.show', $unit_offering->unit) }}" class="btn btn-success"
                           role="button">Show</a>
                    </td>
                </tr>

                </tbody>
            </table>
            @else
                No unit found.
            @endif
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Staff Members</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped mb-4">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th></th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Staff Role</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Campus</th>
                    <th>Contract End Date</th>
                    <th>Proposed Extension</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the staff id, name and code -->
                    <th>Unit Assessor</th>
                    <td>{{$unit_offering->unitAssessor->first_name}}</td>
                    <td>{{$unit_offering->unitAssessor->last_name}}</td>
                    <td>{{$unit_offering->unitAssessor->staff_role}}</td>
                    <td>{{$unit_offering->unitAssessor->email}}</td>
                    <td>{{$unit_offering->unitAssessor->phone}}</td>
                    <td>{{$unit_offering->unitAssessor->campus}}</td>
                    <td>{{$unit_offering->unitAssessor->end_contract}}</td>
                    <td>{{$unit_offering->unitAssessor->proposed_extension}}</td>
                    <td>
                        <a href="{{ route('staff.show', $unit_offering->unitAssessor) }}" class="btn btn-success"
                           role="button">Show</a>
                    </td>
                </tr>
                @if($unit_offering->lecturer1)
                <tr>
                    <!-- show the staff id, name and code -->
                    <th>Lecturer 1</th>
                    <td>{{$unit_offering->lecturer1->first_name}}</td>
                    <td>{{$unit_offering->lecturer1->last_name}}</td>
                    <td>{{$unit_offering->lecturer1->staff_role}}</td>
                    <td>{{$unit_offering->lecturer1->email}}</td>
                    <td>{{$unit_offering->lecturer1->phone}}</td>
                    <td>{{$unit_offering->lecturer1->campus}}</td>
                    <td>{{$unit_offering->lecturer1->end_contract}}</td>
                    <td>{{$unit_offering->lecturer1->proposed_extension}}</td>
                    <td>
                        <a href="{{ route('staff.show', $unit_offering->lecturer1) }}" class="btn btn-success"
                           role="button">Show</a>
                    </td>
                </tr>
                @endif
                @if($unit_offering->lecturer2)
                <tr>
                    <!-- show the staff id, name and code -->
                    <th>Lecturer 2</th>
                    <td>{{$unit_offering->lecturer2->first_name}}</td>
                    <td>{{$unit_offering->lecturer2->last_name}}</td>
                    <td>{{$unit_offering->lecturer2->staff_role}}</td>
                    <td>{{$unit_offering->lecturer2->email}}</td>
                    <td>{{$unit_offering->lecturer2->phone}}</td>
                    <td>{{$unit_offering->lecturer2->campus}}</td>
                    <td>{{$unit_offering->lecturer2->end_contract}}</td>
                    <td>{{$unit_offering->lecturer2->proposed_extension}}</td>
                    <td>
                        <a href="{{ route('staff.show', $unit_offering->lecturer2) }}" class="btn btn-success"
                           role="button">Show</a>
                    </td>
                </tr>
                @endif
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Locations</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if(count($unit_offering->locations)==0)
                No locations found.
            @elseif(count($unit_offering->locations) > 0)
                <table id="example1" class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Location ID</th>
                        <th>Name</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($unit_offering->locations as $location)
                        <tr>
                            <!-- show the location id, name and code -->
                            <td>{{$location->id}}</td>
                            <td>{{$location->name}}</td>
                            <td>
                                <a href="{{ route('locations.show', $location) }}" class="btn btn-success"
                                   role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            @endif
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->

@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
