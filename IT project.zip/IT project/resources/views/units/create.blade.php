@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">New Unit</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - notice it is a POST form as we are posting data. The action of the form is the following route:
         Route::post('/units', [UnitController::class, 'store']);
         This calls the store method of the UnitController to store our new unit -->
        <form role="form" method="POST" action="{{ route('units') }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
            @csrf
            <div class="card-body">
                <div class="form-group">
                    <label for="unit_code">Unit Code</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="8" class="form-control" name="unit_code" id="unit_code" placeholder="Enter the unit code..." required>
                    @error('unit_code')
                    <p class="text-danger">{{$errors->first('unit_code')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="unit_name">Unit Name</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="unit_name" id="unit_name" placeholder="Enter the unit name..." required>
                    @error('unit_name')
                    <p class="text-danger">{{$errors->first('unit_name')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->


                <div class="form-group">
                    <label for="credit_points">Credit Points</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="number" min="1" class="form-control" name="credit_points" id="credit_points" placeholder="Enter the credit points..." required>
                    @error('credit_points')
                    <p class="text-danger">{{$errors->first('credit_points')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->


                <div class="form-group">
                    <label for="aqf_level">AQF Level</label>
                    <select type="number" class="form-control" name="aqf_level" id="aqf_level" value="{{old('aqf_level')}}" required>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                    @error('aqf_level')
                    <p class="text-danger">{{$errors->first('aqf_level')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->



@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
