@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')
    <h2>Unit - {{$unit->unit_code}}</h2>
    <a href="{{route("units")}}" class="btn btn-danger my-2">Back</a>
    <div class="card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Details</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped mb-4">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th>Unit ID</th>
                    <th>Unit Code</th>
                    <th>Unit Name</th>
                    <th>Credit Points</th>
                    <th>AQF Level</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the unit id, name and code -->
                    <td>{{$unit->id}}</td>
                    <td>{{$unit->unit_code}}</td>
                    <td>{{$unit->unit_name}}</td>
                    <td>{{$unit->credit_points}}</td>
                    <td>{{$unit->aqf_level}}</td>
                    <td>
                        <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                        <form role="form" method="POST" action="{{ route('units.destroy', $unit) }}">
                            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                        @csrf
                        <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                        @method('DELETE')

                        <!-- Bootstrap button to edit the unit. Once again, technically this does not need to be in the form. However I added it here
                        otherwise it would not be inline with the delete button. The link matches the name of the following route:
                        Route::get('/units/{unit}/edit', [UnitController::class, 'edit'])->name('units.edit');
                        this route calls the edit function in UnitController and it will add the id of the unit to the wildcard in the
                        endpoint-->
                            <a href="{{ route('units.edit', $unit) }}" class="btn btn-warning"
                               role="button">Edit</a>

                            <!-- Bootstrap button to delete the unit. This button submits the form. If you look at the form action above you will see that the action calls
                            Route::delete('/units/{unit}/destroy', [UnitController::class, 'destroy'])->name('units.destroy');
                            and it will add the id of the unit to the wildcard in the endpoint-->
                            <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this unit?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>

                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Courses</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if (count($unit->courses) == 0)
                No courses found
            @elseif (count($unit->courses) > 0)
            <!-- yes we have courses so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Course ID</th>
                        <th>Course Code</th>
                        <th>Course Title</th>
                        <th>Course Type</th>
                        <th>Credit Points</th>
                        <th>AQF Level</th>
                        <th>Unit Role in Course</th>
                        <!--<th>Deleted</th>-->
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- using a blade foreach loop to loop through the courses - https://laravel.com/docs/7.x/blade#loops -->
                    @foreach ($unit->courses as $course)
                        <tr>
                            <!-- show the course id, course code, course title, course type, credit points, aqf level and deleted -->
                            <td>{{$course->id}}</td>
                            <td>{{$course->course_code}}</td>
                            <td>{{$course->course_title}}</td>
                            <td>{{$course->course_type}}</td>
                            <td>{{$course->credit_points}}</td>
                            <td>{{$course->aqf_level}}</td>
                            <td>{{$course->pivot->type}} Unit</td>
                        <!--<td>{{$course->deleted}}</td>-->
                            <td>
                                <a href="{{ route('courses.show', $course) }}" class="btn btn-success" role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Course ID</th>
                        <th>Course Code</th>
                        <th>Course Title</th>
                        <th>Course Type</th>
                        <th>Credit Points</th>
                        <th>AQF Level</th>
                        <th>Unit Role in Course</th>
                        <!--<th>Deleted</th>-->
                        <th></th>
                    </tr>
                    </tfoot>
                </table>

            @endif
        </div>
    </div>
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Majors</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if (count($unit->majors) == 0)
                No majors found
            @elseif (count($unit->majors) > 0)
            <!-- yes we have majors so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Major Id</th>
                        <th>Course</th>
                        <th>Name</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- using a blade foreach loop to loop through the locations - https://laravel.com/docs/7.x/blade#loops -->
                    @foreach ($unit->majors as $major)
                        <tr>
                            <!-- show the location id, name and code -->
                            <td>{{$major->id}}</td>
                            <td>{{$major->course->course_title}}</td>
                            <td>{{$major->name}}</td>
                            <td>
                                <a href="{{ route('majors.show', $major) }}" class="btn btn-success" role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Major Id</th>
                        <th>Course</th>
                        <th>Name</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>

            @endif
        </div>
    </div>
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Unit Offerings</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if (count($unit->unitOfferings) == 0)
                No unit offerings found
            @elseif (count($unit->unitOfferings) > 0)
            <!-- yes we have unit_offerings so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Unit Offering ID</th>
                        <th>Study Period</th>
                        <th>Year</th>
                        <th>Unit Assessor</th>
                        <th>Lecturer 1</th>
                        <th>Lecturer 2</th>
                        <th>Locations Offered</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- using a blade foreach loop to loop through the unit_offerings - https://laravel.com/docs/7.x/blade#loops -->
                    @foreach ($unit->unitOfferings as $unit_offering)
                        <tr>
                            <!-- show the unit_offering id, name and code -->
                            <td>{{$unit_offering->id}}</td>
                            <td>{{$unit_offering->study_period}}</td>
                            <td>{{$unit_offering->year}}</td>
                            <td>{{$unit_offering->unitAssessor->first_name}} {{$unit_offering->unitAssessor->last_name}}</td>
                            <td>@if($unit_offering->lecturer1){{$unit_offering->lecturer1->first_name}} {{$unit_offering->lecturer1->last_name}}@endif</td>
                            <td>@if($unit_offering->lecturer2){{$unit_offering->lecturer2->first_name}} {{$unit_offering->lecturer2->last_name}}@endif</td>
                            <td>{{$unit_offering->locations->count()}}</td>
                            <td>
                                <a href="{{ route('unit_offerings.show', $unit_offering) }}" class="btn btn-success" role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Unit Offering ID</th>
                        <th>Study Period</th>
                        <th>Year</th>
                        <th>Unit Assessor</th>
                        <th>Lecturer 1</th>
                        <th>Lecturer 2</th>
                        <th>Locations Offered</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>

            @endif
        </div>
    </div>
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Learning Outcomes</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if (count($unit->learningOutcomes) == 0)
                No learning outcomes found
            @elseif (count($unit->learningOutcomes) > 0)
            <!-- yes we have staff so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>ID</th>
                        <th>Learning Outcome Code</th>
                        <th>Description</th>
                        <th>Type</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- using a blade foreach loop to loop through the staff - https://laravel.com/docs/7.x/blade#loops -->
                    @foreach ($unit->learningOutcomes as $learnOutcome)
                        <tr>
                            <!-- show the staff member id, name and code -->
                            <td>{{$learnOutcome->id}}</td>
                            <td>{{$learnOutcome->code}}</td>
                            <td>{{$learnOutcome->description}}</td>
                            <td>{{$learnOutcome->type}}</td>
                            <td>
                                <a href="{{ route('learningOutcomes.show', $learnOutcome) }}" class="btn btn-success" role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Learning Outcome Code</th>
                        <th>Description</th>
                        <th>Type</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>
            @endif
        </div>
    </div>

    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Add Learning Outcome</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <!-- /.card-header -->

            <!-- form start - notice it is a POST form as we are posting data. The action of the form is the following route:
             Route::post('/staff', [StaffController::class, 'store']);
             This calls the store method of the StaffController to store our new staff -->
            <form role="form" method="POST" action="{{ route('learningOutcomes') }}">

                <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                @csrf
                <div class="card-body">
                    <div class="form-group">
                        <label for="code">Learning Outcome Code</label>
                        <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                        You must have these so that when we post the data we can get it from the request.
                        Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                         -->
                        <input type="text" maxlength="191" class="form-control" name="code" id="code" placeholder="Enter the Learning Outcome Code..." value="{{old('code')}}" required>
                        @error('code')
                        <p class="danger">{{$errors->first('code')}}</p>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                        You must have these so that when we post the data we can get it from the request.
                        Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                         -->
                        <input type="text" maxlength="191" class="form-control" name="description" id="description" placeholder="Enter the Description..." value="{{old('description')}}" required>
                        @error('description')
                        <p class="text-danger">{{$errors->first('description')}}</p>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="type">Type</label>
                        <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                        You must have these so that when we post the data we can get it from the request.
                        Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                         -->
                        <select class="form-control" name="type" id="type" value="Unit" required>
                            <option value="Unit">Unit</option>
                        </select>

                    </div>
                    <div class="form-group" id="unit_div">
                        <label for="unit_id">Unit</label>
                        <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                        You must have these so that when we post the data we can get it from the request.
                        Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                         -->

                        <select class="form-control" id="unit_id" name="unit_id" value="{{old('unit_id')}}">

                            <option value="{{$unit->id}}">{{$unit->unit_name}}</option>

                        </select>
                        @error('unit_id')
                        <p class="danger">{{$errors->first('unit_id')}}</p>
                        @enderror


                    </div>
                    <!-- submit the form -->
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <!-- /.card-body -->
            </form>


        </div>
    </div>

@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
