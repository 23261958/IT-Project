@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Unit - {{$unit->unit_code}}</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - The action of the form is the following route:
         Route::put('/units/{unit}', [UnitController::class, 'update'])->name('units.update');
         This calls the update method of the UnitController to update our unit.
         Notice it is a POST form but our route needs a PUT.... -->
        <form role="form" method="POST" action="{{ route('units.update', $unit) }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
        @csrf
        <!-- override the POST method with a PUT so we have a put method. We need to do this as browsers
                                do not support PUT via 'HTML form' submission -->
            @method('PUT')
            <div class="card-body">
                <div class="form-group">
                    <label for="id">Unit ID</label>
                    <!-- input for id but we have disabled this so the user can not change it -->
                    <input type="number" class="form-control" name="id" id="id" value="{{ $unit->id }}" disabled>
                </div>
                <div class="form-group">
                    <label for="unit_code">Unit Code</label>
                    <!-- input for the unit name. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" maxlength="8" class="form-control" name="unit_code" id="unit_code" placeholder="Enter the unit code..." value="{{($errors->any()) ? old('unit_code') : $unit->unit_code}}" required>
                    @error('unit_code')
                    <p class="text-danger">{{$errors->first('unit_code')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="unit_name">Unit Name</label>
                    <!-- input for the unit code. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" maxlength="191" class="form-control" name="unit_name" id="unit_name" placeholder="Enter the unit name..." value="{{($errors->any()) ? old('unit_name') : $unit->unit_name}}" required>
                    @error('unit_name')
                    <p class="text-danger">{{$errors->first('unit_name')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="credit_points">Credit Points</label>
                    <!-- input for the unit code. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="number" min="1" class="form-control" name="credit_points" id="credit_points" placeholder="Enter the credit points..." value="{{($errors->any()) ? old('credit_points') : $unit->credit_points}}" required>
                    @error('credit_points')
                    <p class="text-danger">{{$errors->first('credit_points')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="aqf_level">AQF Level</label>
                    <select type="number" class="form-control" name="aqf_level" id="aqf_level" value="{{old('aqf_level')}}" required>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>


                    </select>
                    @error('aqf_level')
                    <p class="text-danger">{{$errors->first('aqf_level')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
