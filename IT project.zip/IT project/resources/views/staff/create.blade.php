@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">New Staff</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - notice it is a POST form as we are posting data. The action of the form is the following route:
         Route::post('/staff', [StaffController::class, 'store']);
         This calls the store method of the StaffController to store our new staff -->
        <form role="form" method="POST" action="{{ route('staff') }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
            @csrf
            <div class="card-body">
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="first_name" id="first_name" placeholder="Enter the staff member's first name..." value="{{old('first_name')}}" required>
                    @error('first_name')
                        <p class="danger">{{$errors->first('first_name')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="last_name" id="last_name" placeholder="Enter the staff member's last name..." value="{{old('last_name')}}" required>
                    @error('last_name')
                        <p class="text-danger">{{$errors->first('last_name')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="staff_role">Role</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="staff_role" id="staff_role" placeholder="Enter the staff member's role at the university..." value="{{old('staff_role')}}" required>
                    @error('staff_role')
                        <p class="text-danger">{{$errors->first('staff_role')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="email" id="email" placeholder="Enter the staff member's email address..." value="{{old('email')}}" required>
                    @error('email')
                        <p class="text-danger">{{$errors->first('email')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="10" class="form-control" name="phone" id="phone" placeholder="Enter the staff member's phone number..." value="{{old('phone')}}" required>
                    @error('phone')
                        <p class="text-danger">{{$errors->first('phone')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="campus">Campus</label><br>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    @foreach($locations as $location)
                        <input type="radio" id="{{$location->name}}" name="campus" value="{{$location->name}}">
                        <label for="{{$location->name}}">{{$location->name}}</label>
                    @endforeach
                    @error('campus')
                        <p class="text-danger">{{$errors->first('campus')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="end_contract">Contract End Date</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="date" class="form-control" name="end_contract" id="end_contract" min="{{date("Y-m-d")}}" value="{{old('end_contract')}}" required>
                    @error('end_contract')
                        <p class="text-danger">{{$errors->first('end_contract')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="proposed_extension">Proposed Extension</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="proposed_extension" id="proposed_extension" placeholder="Enter the staff member's proposed extension period..." value="{{old('proposed_extension')}}">
                    @error('proposed_extension')
                        <p class="text-danger">{{$errors->first('proposed_extension')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->



@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
