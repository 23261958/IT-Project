@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')
    <h2>Staff - {{$staff->first_name}} {{$staff->last_name}}</h2>
    <a href="{{route("staff")}}" class="btn btn-danger my-2">Back</a>
    <div class="card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Details</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th>Staff ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Staff Role</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Campus</th>
                    <th>Contract End Date</th>
                    <th>Proposed Extension</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the staff id, name and code -->
                    <td>{{$staff->id}}</td>
                    <td>{{$staff->first_name}}</td>
                    <td>{{$staff->last_name}}</td>
                    <td>{{$staff->staff_role}}</td>
                    <td>{{$staff->email}}</td>
                    <td>{{$staff->phone}}</td>
                    <td>{{$staff->campus}}</td>
                    <td>{{$staff->end_contract}}</td>
                    <td>{{$staff->proposed_extension}}</td>
                    <td>
                        <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                        <form role="form" method="POST" action="{{ route('staff.destroy', $staff) }}">
                            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                        @csrf
                        <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                        @method('DELETE')

                           <!-- Bootstrap button to edit the staff. Once again, technically this does not need to be in the form. However I added it here
                        otherwise it would not be inline with the delete button. The link matches the name of the following route:
                        Route::get('/staff/{staff}/edit', [StaffController::class, 'edit'])->name('staff.edit');
                        this route calls the edit function in StaffController and it will add the id of the staff to the wildcard in the
                        endpoint-->
                            <a href="{{ route('staff.edit', $staff) }}" class="btn btn-warning"
                               role="button">Edit</a>

                            <!-- Bootstrap button to delete the staff. This button submits the form. If you look at the form action above you will see that the action calls
                            Route::delete('/staff/{staff}/destroy', [StaffController::class, 'destroy'])->name('staff.destroy');
                            and it will add the id of the staff to the wildcard in the endpoint-->
                            <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this staff?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>

                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Unit Offerings</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @php
                $unitOfferings = $staff->unitAssessors->merge($staff->lecturer1s)->merge($staff->lecturer2s)->unique();
            @endphp
            @if (count($unitOfferings) == 0)
                No unit offerings found.
            @elseif (count($unitOfferings) > 0)
            <!-- yes we have unit_offerings so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Unit Offering ID</th>
                        <th>Unit</th>
                        <th>Study Period</th>
                        <th>Year</th>
                        <th>Unit Assessor</th>
                        <th>Lecturer 1</th>
                        <th>Lecturer 2</th>
                        <th>Locations Offered</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- using a blade foreach loop to loop through the unit_offerings - https://laravel.com/docs/7.x/blade#loops -->
                    @foreach ($unitOfferings as $unit_offering)
                        <tr>
                            <!-- show the unit_offering id, name and code -->
                            <td>{{$unit_offering->id}}</td>
                            <td>{{$unit_offering->unit->unit_name}}</td>
                            <td>{{$unit_offering->study_period}}</td>
                            <td>{{$unit_offering->year}}</td>
                            <td>{{$unit_offering->unitAssessor->first_name}} {{$unit_offering->unitAssessor->last_name}}</td>
                            <td>@if($unit_offering->lecturer1){{$unit_offering->lecturer1->first_name}} {{$unit_offering->lecturer1->last_name}}@endif</td>
                            <td>@if($unit_offering->lecturer2){{$unit_offering->lecturer2->first_name}} {{$unit_offering->lecturer2->last_name}}@endif</td>
                            <td>{{$unit_offering->locations->count()}}</td>
                            <td>
                                <a href="{{ route('unit_offerings.show', $unit_offering) }}" class="btn btn-success" role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Unit Offering ID</th>
                        <th>Unit</th>
                        <th>Study Period</th>
                        <th>Year</th>
                        <th>Unit Assessor</th>
                        <th>Lecturer 1</th>
                        <th>Lecturer 2</th>
                        <th>Locations Offered</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>

            @endif
        </div>
    </div>

@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
