@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
    <link rel="stylesheet" href="{{ asset("plugins/datatables-bs4/css/dataTables.bootstrap4.min.css") }}">
    <link rel="stylesheet" href="{{ asset("plugins/datatables-responsive/css/responsive.bootstrap4.min.css") }}">
    <link rel="stylesheet" href="{{ asset("plugins/datatables-buttons/css/buttons.bootstrap4.min.css") }}">
@endsection

@section('contentBody')

    <!-- START ACCORDION & CAROUSEL-->


    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-chart-pie mr-1"></i>
                Course Designer Dashboard
            </h3>
            <div class="card-tools">
                <ul class="nav nav-pills ml-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#course_design" data-toggle="tab">Course Design</a>
                    </li>
                    @if(Auth::user()->roles->contains('id','3') || Auth::user()->roles->contains('id','1'))
                    <li class="nav-item">
                        <a class="nav-link" href="#staff" data-toggle="tab">Staff</a>
                    </li>
                    @endif
                    <li class="nav-item">
                        <a class="nav-link" href="#unit_offering" data-toggle="tab">Unit Offering</a>
                    </li>
                </ul>
            </div>
        </div><!-- /.card-header -->
        <div class="card-body">
            <div class="tab-content p-0">
                <!-- Morris chart - Sales -->
                <div class="chart tab-pane active" id="course_design"
                     style="position: relative">

                    <!--<div class="card-header">
                        <h3 class="card-title">Course Design</h3>
                    </div>
                    <br>-->
                    <div id="accordion">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h4 class="card-title w-100">
                                    <a class="d-block w-100" data-toggle="collapse" href="#collapseOne">
                                        Courses
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseOne" class="collapse show" data-parent="#accordion">


                                <div class="card">
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <!-- using a blade if statement to see if we have any courses to show, see
                                         https://laravel.com/docs/7.x/blade#if-statements -->
                                        @if (count($courses) == 0)
                                            No courses found
                                    @elseif (count($courses) > 0)
                                        <!-- yes we have courses so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                                            <table id="example1" class="table table-bordered table-striped">
                                                <thead>
                                                <tr>
                                                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                                                    <th>Course ID</th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Course Type</th>
                                                    <th>Credit Points</th>
                                                    <th>AQF Level</th>
                                                    <!--<th>Deleted</th>-->
                                                    <th><a class="btn btn-primary" href="{{ route('courses.create') }}" role="button">New Course</a></th>

                                                </tr>
                                                </thead>
                                                <tbody>
                                                <!-- using a blade foreach loop to loop through the courses - https://laravel.com/docs/7.x/blade#loops -->
                                                @foreach ($courses as $course)
                                                    <tr>
                                                        <!-- show the course id, course code, course title, course type, credit points, aqf level and deleted -->
                                                        <td>{{$course->id}}</td>
                                                        <td>{{$course->course_code}}</td>
                                                        <td>{{$course->course_title}}</td>
                                                        <td>{{$course->course_type}}</td>
                                                        <td>{{$course->credit_points}}</td>
                                                        <td>{{$course->aqf_level}}</td>



                                                        <td>

                                                            <a href="{{ route('courses.show', $course) }}" class="btn btn-success"
                                                               role="button">Show</a>

                                                        </td>
                                                    </tr>
                                                @endforeach

                                                </tbody>
                                                <tfoot>
                                                <tr>
                                                    <th>Course ID</th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Course Type</th>
                                                    <th>Credit Points</th>
                                                    <th>AQF Level</th>
                                                    <th></th>
                                                    <!--<th>Deleted</th>-->

                                                </tr>
                                                </tfoot>
                                            </table>

                                    @endif


                                    <!-- /.card-body -->
                                    </div>

                                </div>
                            </div>
                            <div class="card card-danger">
                                <div class="card-header">
                                    <h4 class="card-title w-100">
                                        <a class="d-block w-100" data-toggle="collapse" href="#collapseTwo">
                                            Majors
                                        </a>
                                    </h4>
                                </div>
                                <div id="collapseTwo" class="collapse" data-parent="#accordion">
                                    <div class="card-body">
                                        <div class="card-body">
                                            <!-- using a blade if statement to see if we have any locations to show, see
                                             https://laravel.com/docs/7.x/blade#if-statements -->
                                            @if (count($majors) == 0)
                                                No Majors found
                                            @elseif (count($majors) > 0)
                                            <!-- yes we have majors so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                                                <table id="example2" class="table table-bordered table-striped">
                                                    <thead>
                                                    <tr>
                                                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                                                        <th>Major Id</th>
                                                        <th>Course Id</th>
                                                        <th>Name</th>
                                                        <th><a class="btn btn-primary" href="{{ route('majors.create') }}" role="button">New Major</a></th>

                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <!-- using a blade foreach loop to loop through the locations - https://laravel.com/docs/7.x/blade#loops -->
                                                    @foreach ($majors as $major)
                                                        <tr>
                                                            <!-- show the location id, name and code -->
                                                            <td>{{$major->id}}</td>
                                                            <td>{{$major->course_id}}</td>
                                                            <td>{{$major->name}}</td>
                                                            <td>

                                                                <a href="{{ route('majors.show', $major) }}" class="btn btn-success"
                                                                   role="button">Show</a>

                                                            </td>

                                                        </tr>
                                                    @endforeach

                                                    </tbody>
                                                    <tfoot>
                                                    <tr>
                                                        <th>Major Id</th>
                                                        <th>Course Id</th>
                                                        <th>Name</th>
                                                        <th></th>

                                                    </tr>
                                                    </tfoot>
                                                </table>

                                            @endif

                                        </div>
                                        <!-- /.card-body -->
                                    </div>
                                    <!-- /.card -->



                                </div>
                                <div class="card card-success">
                                    <div class="card-header">
                                        <h4 class="card-title w-100">
                                            <a class="d-block w-100" data-toggle="collapse" href="#collapseThree">
                                                Units
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseThree" class="collapse" data-parent="#accordion">
                                        <div class="card-body">
                                            <div class="card">

                                                <div class="card-body">
                                                    <table id="example3" class="table table-bordered table-striped mb-4">
                                                        <thead>
                                                        <tr>
                                                            <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                                                            <th>Unit ID</th>
                                                            <th>Unit Code</th>
                                                            <th>Unit Name</th>
                                                            <th>Credit Points</th>
                                                            <th>AQF Level</th>
                                                            <th><a class="btn btn-primary" href="{{ route('units.create') }}" role="button">New Unit</a></th>

                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        @foreach ($units as $unit)
                                                            <tr>

                                                                <!-- show the unit id, name and code -->
                                                                <td>{{$unit->id}}</td>
                                                                <td>{{$unit->unit_code}}</td>
                                                                <td>{{$unit->unit_name}}</td>
                                                                <td>{{$unit->credit_points}}</td>
                                                                <td>{{$unit->aqf_level}}</td>
                                                                <td>

                                                                    <a href="{{ route('units.show', $unit) }}" class="btn btn-success"
                                                                       role="button">Show</a>

                                                                </td>

                                                            </tr>
                                                        @endforeach
                                                        </tbody>
                                                    </table>



                                                </div>
                                                <!-- /.card-body -->
                                            </div>
                                            <!-- /.card -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                </div>
                <div class="chart tab-pane" id="staff" style="position: relative">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">All Staff Members</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <!-- using a blade if statement to see if we have any staff to show, see
                             https://laravel.com/docs/7.x/blade#if-statements -->
                            @if (count($staff) == 0)
                                No staff found
                            @elseif (count($staff) > 0)
                            <!-- yes we have staff so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                                <table id="example4" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                                        <th>Staff ID</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Staff Role</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Campus</th>
                                        <th>Contract End Date</th>
                                        <th>Proposed Extension</th>
                                        <th><a class="btn btn-primary" href="{{ route('staff.create') }}" role="button">New Staff</a></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <!-- using a blade foreach loop to loop through the staff - https://laravel.com/docs/7.x/blade#loops -->
                                    @foreach ($staff as $member)
                                        <tr>
                                            <!-- show the staff member id, name and code -->
                                            <td>{{$member->id}}</td>
                                            <td>{{$member->first_name}}</td>
                                            <td>{{$member->last_name}}</td>
                                            <td>{{$member->staff_role}}</td>
                                            <td>{{$member->email}}</td>
                                            <td>{{$member->phone}}</td>
                                            <td>{{$member->campus}}</td>
                                            <td>{{$member->end_contract}}</td>
                                            <td>{{$member->proposed_extension}}</td>
                                            <td>
                                                <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                                                <form role="form" method="POST" action="{{ route('staff.destroy', $member) }}">
                                                    <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                                                @csrf
                                                <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                                                @method('DELETE')

                                                <!-- Bootstrap button to show the staff member. Technically this does not need to be in the form. However I added it here
                                otherwise it would not be inline with the delete button. The link matches the name of the following route:
                                Route::get('/staff/{staff member}/show', [StaffController::class, 'show'])->name('staff.show');
                                this route calls the show function in StaffController and it will add the id of the staff to the wildcard in the
                                endpoint-->
                                                    <a href="{{ route('staff.show', $member) }}" class="btn btn-success"
                                                       role="button">Show</a>

                                                    <!-- Bootstrap button to edit the staff member. Once again, technically this does not need to be in the form. However I added it here
                                                otherwise it would not be inline with the delete button. The link matches the name of the following route:
                                                Route::get('/staff/{staff member}/edit', [StaffController::class, 'edit'])->name('staff.edit');
                                                this route calls the edit function in StaffController and it will add the id of the staff member to the wildcard in the
                                                endpoint-->
                                                    <a href="{{ route('staff.edit', $member) }}" class="btn btn-warning"
                                                       role="button">Edit</a>

                                                    <!-- Bootstrap button to delete the staff member. This button submits the form. If you look at the form action above you will see that the action calls
                                                    Route::delete('/staff/{staff member}/destroy', [StaffController::class, 'destroy'])->name('staff.destroy');
                                                    and it will add the id of the staff member to the wildcard in the endpoint-->
                                                    <button type="submit" class="btn btn-danger"
                                                            onclick="return confirm('Are you sure you want to delete this staff member?')">
                                                        Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach

                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>Staff ID</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Staff Role</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Campus</th>
                                        <th>Contract End Date</th>
                                        <th>Proposed Extension</th>
                                        <th></th>
                                    </tr>
                                    </tfoot>
                                </table>

                            @endif

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                </div>
                <div class="chart tab-pane" id="unit_offering" style="position: relative">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">All Unit Offerings</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <!-- using a blade if statement to see if we have any unit_offerings to show, see
                             https://laravel.com/docs/7.x/blade#if-statements -->
                            @if (count($unit_offerings) == 0)
                                No unit offerings found
                            @elseif (count($unit_offerings) > 0)
                            <!-- yes we have unit_offerings so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                                <table id="example5" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                                        <th>Unit Offering ID</th>
                                        <th>Unit</th>
                                        <th>Study Period</th>
                                        <th>Year</th>
                                        <th>Unit Assessor</th>
                                        <th>Lecturer 1</th>
                                        <th>Lecturer 2</th>
                                        <th>Locations Offered</th>
                                        <th><a class="btn btn-primary" href="{{ route('unit_offerings.create') }}" role="button">New Unit Offering</a></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <!-- using a blade foreach loop to loop through the unit_offerings - https://laravel.com/docs/7.x/blade#loops -->
                                    @foreach ($unit_offerings as $unit_offering)
                                        <tr>
                                            <!-- show the unit_offering id, name and code -->
                                            <td>{{$unit_offering->id}}</td>
                                            <td>{{$unit_offering->unit->unit_name}}</td>
                                            <td>{{$unit_offering->study_period}}</td>
                                            <td>{{$unit_offering->year}}</td>
                                            <td>{{$unit_offering->unitAssessor->first_name}} {{$unit_offering->unitAssessor->last_name}}</td>
                                            <td>@if($unit_offering->lecturer1){{$unit_offering->lecturer1->first_name}} {{$unit_offering->lecturer1->last_name}}@endif</td>
                                            <td>@if($unit_offering->lecturer2){{$unit_offering->lecturer2->first_name}} {{$unit_offering->lecturer2->last_name}}@endif</td>
                                            <td>{{$unit_offering->locations->count()}}</td>
                                            <td>
                                                <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                                                <form role="form" method="POST" action="{{ route('unit_offerings.destroy', $unit_offering) }}">
                                                    <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                                                @csrf
                                                <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                                                @method('DELETE')

                                                <!-- Bootstrap button to show the unit_offering. Technically this does not need to be in the form. However I added it here
                                otherwise it would not be inline with the delete button. The link matches the name of the following route:
                                Route::get('/unit_offerings/{unit_offering}/show', [UnitOfferingController::class, 'show'])->name('unit_offerings.show');
                                this route calls the show function in UnitOfferingController and it will add the id of the unit_offerings to the wildcard in the
                                endpoint-->
                                                    <a href="{{ route('unit_offerings.show', $unit_offering) }}" class="btn btn-success"
                                                       role="button">Show</a>

                                                    <!-- Bootstrap button to edit the unit_offering. Once again, technically this does not need to be in the form. However I added it here
                                                otherwise it would not be inline with the delete button. The link matches the name of the following route:
                                                Route::get('/unit_offerings/{unit_offering}/edit', [UnitOfferingController::class, 'edit'])->name('unit_offerings.edit');
                                                this route calls the edit function in UnitOfferingController and it will add the id of the unit_offering to the wildcard in the
                                                endpoint-->
                                                    <a href="{{ route('unit_offerings.edit', $unit_offering) }}" class="btn btn-warning"
                                                       role="button">Edit</a>

                                                    <!-- Bootstrap button to delete the unit_offering. This button submits the form. If you look at the form action above you will see that the action calls
                                                    Route::delete('/unit_offerings/{unit_offering}/destroy', [UnitOfferingController::class, 'destroy'])->name('unit_offerings.destroy');
                                                    and it will add the id of the unit_offering to the wildcard in the endpoint-->
                                                    <button type="submit" class="btn btn-danger"
                                                            onclick="return confirm('Are you sure you want to delete this unit_offering?')">
                                                        Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach

                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>Unit Offering ID</th>
                                        <th>Unit</th>
                                        <th>Study Period</th>
                                        <th>Year</th>
                                        <th>Unit Assessor</th>
                                        <th>Lecturer 1</th>
                                        <th>Lecturer 2</th>
                                        <th>Locations Offered</th>
                                        <th></th>
                                    </tr>
                                    </tfoot>
                                </table>

                            @endif

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.card-body -->
    </div>
    <!-- /.card -->

@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
    <script src="{{ asset("plugins/datatables/jquery.dataTables.min.js") }}"></script>
    <script src="{{ asset("plugins/datatables-bs4/js/dataTables.bootstrap4.min.js") }}"></script>
    <script src="{{ asset("plugins/datatables-responsive/js/dataTables.responsive.min.js") }}"></script>
    <script src="{{ asset("plugins/datatables-responsive/js/responsive.bootstrap4.min.js") }}"></script>
    <script>
        $(function () {
            $("#example1").DataTable({
                "autoWidth": true,
            });
        });
        $(function () {
            $("#example2").DataTable({
                "autoWidth": true,
            });
        });
        $(function () {
            $("#example3").DataTable({
                "autoWidth": true,
            });
        });
        $(function () {
            $("#example4").DataTable({
                "autoWidth": true,
            });
        });
        $(function () {
            $("#example5").DataTable({
                "autoWidth": true,
            });
        });
    </script>
@endsection
