@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
    <!-- DataTables -->
    <link rel="stylesheet" href="{{ asset("plugins/datatables-bs4/css/dataTables.bootstrap4.min.css") }}">
    <link rel="stylesheet" href="{{ asset("plugins/datatables-responsive/css/responsive.bootstrap4.min.css") }}">
    <link rel="stylesheet" href="{{ asset("plugins/datatables-buttons/css/buttons.bootstrap4.min.css") }}">
@endsection

@section('contentBody')

    <!-- using a Bootstrap button (see https://getbootstrap.com/docs/4.0/components/buttons/) as a link to go to the roles.create route.
    The link matches the name of the following route:
    Route::get('/roles/create', [RoleController::class, 'create'])->name('roles.create');
    this route calls the create function in the RoleController  -->
    <a class="btn btn-primary" href="{{ route('roles.create') }}" role="button">New Role</a>

    <br><br>

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">All Roles</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <!-- using a blade if statement to see if we have any roles to show, see
             https://laravel.com/docs/7.x/blade#if-statements -->
            @if (count($roles) == 0)
                No roles found
            @elseif (count($roles) > 0)
            <!-- yes we have roles so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Role ID</th>
                        <th>Role Name</th>
                        <th>Permissions Assigned</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- using a blade foreach loop to loop through the roles - https://laravel.com/docs/7.x/blade#loops -->
                    @foreach ($roles as $role)
                        <tr>
                            <!-- show the role id, and role name -->
                            <td>{{$role->id}}</td>
                            <td>{{$role->role_name}}</td>
                            <td>{{$role->permissions->count()}}</td>
                            <td>
                                <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                                <form role="form" method="POST" action="{{ route('roles.destroy', $role) }}">
                                    <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                                @csrf
                                <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                                @method('DELETE')

                                <!-- Bootstrap button to show the role. Technically this does not need to be in the form. However I added it here
                                otherwise it would not be inline with the delete button. The link matches the name of the following route:
                                Route::get('/roles/{role}/show', [RoleController::class, 'show'])->name('roles.show');
                                this route calls the show function in RoleController and it will add the id of the roles to the wildcard in the
                                endpoint-->
                                    <a href="{{ route('roles.show', $role) }}" class="btn btn-success"
                                       role="button">Show</a>

                                    <!-- Bootstrap button to edit the role. Once again, technically this does not need to be in the form. However I added it here
                                otherwise it would not be inline with the delete button. The link matches the name of the following route:
                                Route::get('/roles/{role}/edit', [RoleController::class, 'edit'])->name('roles.edit');
                                this route calls the edit function in RoleController and it will add the id of the role to the wildcard in the
                                endpoint-->
                                    <a href="{{ route('roles.edit', $role) }}" class="btn btn-warning"
                                       role="button">Edit</a>

                                    <!-- Bootstrap button to delete the role. This button submits the form. If you look at the form action above you will see that the action calls
                                    Route::delete('/roles/{role}/destroy', [RoleController::class, 'destroy'])->name('roles.destroy');
                                    and it will add the id of the role to the wildcard in the endpoint-->
                                    <button type="submit" class="btn btn-danger"
                                            onclick="return confirm('Are you sure you want to delete this role?')">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Role ID</th>
                        <th>Role Name</th>
                        <th>Permissions Assigned</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>

            @endif

        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->

    <!-- The Modal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body" id="modalBody">
                    Modal body..
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
    <script src="{{ asset("plugins/datatables/jquery.dataTables.min.js") }}"></script>
    <script src="{{ asset("plugins/datatables-bs4/js/dataTables.bootstrap4.min.js") }}"></script>
    <script src="{{ asset("plugins/datatables-responsive/js/dataTables.responsive.min.js") }}"></script>
    <script src="{{ asset("plugins/datatables-responsive/js/responsive.bootstrap4.min.js") }}"></script>
    <script>
        $(function () {
            $("#example1").DataTable({
                "autoWidth": true,
            });

        });

        var msgAdd = '{{Session::get('alertAdd')}}';
        var existAdd = '{{Session::has('alertAdd')}}';
        if(existAdd){
            if(msgAdd=="1")
            {
                $("#modalBody").html("Successfully Added!");
                $('#myModal').modal('show');
            }
            else
            {
                $("#modalBody").html("Adding Failed!");
                $('#myModal').modal('show');
            }
        }

        var msgEdit = '{{Session::get('alertEdit')}}';
        var existEdit = '{{Session::has('alertEdit')}}';
        if(existEdit){
            if(msgEdit=="1")
            {
                $("#modalBody").html("Successfully Edited!");
                $('#myModal').modal('show');
            }
            else
            {
                $("#modalBody").html("Edit Failed!");
                $('#myModal').modal('show');
            }
        }

        var msgDelete = '{{Session::get('alertDelete')}}';
        var existDelete = '{{Session::has('alertDelete')}}';
        if(existDelete){
            if(msgDelete=="1")
            {
                $("#modalBody").html("Successfully Deleted!");
                $('#myModal').modal('show');
            }
            else
            {
                $("#modalBody").html("Delete Failed!");
                $('#myModal').modal('show');
            }
        }


    </script>
@endsection
