<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="{{url("/dashboard")}}" class="nav-link">Dashboard</a>
        </li>
    </ul>

    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                {{ Auth::user()->name }}
            </a>

            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="{{ route('users.accounts.show', Auth::user()) }}">My Account</a>
                <a class="dropdown-item" href="{{ route('logout') }}"
                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    Logout
                </a>

                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
            </div>
        </li>
    </ul>



</nav>
<!-- /.navbar -->

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="{{url("/dashboard")}}" class="brand-link">
        <span class="brand-text font-weight-light">CourseDesigner</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
                     with font-awesome or any other icon font library -->

                @if(Auth::user()->roles->contains('id','2') || Auth::user()->roles->contains('id','1'))
                    <h4 class="brand-text text-white font-weight-light overflow-hidden navBtn @if(Auth::user()->roles->contains('id','1')) navItem @endif" @if(Auth::user()->roles->contains('id','1')) boxName='uDesign'@endif>Unit Design</h4>
                    <div class="uDesign @if(Auth::user()->roles->contains('id','1')) closeNav @endif">
                    <li class="nav-item">
                        <a href="{{url("/dashboard")}}" class="nav-link">
                            <i class="nav-icon fas fa-tachometer-alt fa-fw"></i>
                            <p class="text-nowrap">Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/courses")}}" class="nav-link">
                            <i class="nav-icon fas fa-book fa-fw"></i>
                            <p class="text-nowrap">Courses</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/majors")}}" class="nav-link">
                            <i class="nav-icon fas fa-project-diagram fa-fw"></i>
                            <p class="text-nowrap">Majors</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/units")}}" class="nav-link">
                            <i class="nav-icon fas fa-th fa-fw"></i>
                            <p class="text-nowrap">Units</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/locations")}}" class="nav-link">
                            <i class="nav-icon fas fa-map-marker fa-fw"></i>
                            <p class="text-nowrap">Locations</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/learningOutcomes")}}" class="nav-link">
                            <i class="nav-icon fas fa-award fa-fw"></i>
                            <p class="text-nowrap">Learning Outcomes</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/competencies")}}" class="nav-link">
                            <i class="nav-icon fas fa-check-square fa-fw"></i>
                            <p class="text-nowrap">Competencies</p>
                        </a>
                    </li>
                    </div>
                @endif
                @if(Auth::user()->roles->contains('id','3') || Auth::user()->roles->contains('id','1'))
                    <h4 class="brand-text text-white font-weight-light navBtn @if(Auth::user()->roles->contains('id','1')) navItem @endif" @if(Auth::user()->roles->contains('id','1')) boxName='sManagement'@endif">Staff Management</h4>
                    <div class="sManagement @if(Auth::user()->roles->contains('id','1')) closeNav @endif">
                    <li class="nav-item">
                        <a href="{{url("/staff")}}" class="nav-link">
                            <i class="nav-icon fas fa-user fa-fw"></i>
                            <p class="text-nowrap">Staff</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/units")}}" class="nav-link">
                            <i class="nav-icon fas fa-th fa-fw"></i>
                            <p class="text-nowrap">Units</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/unit_offerings")}}" class="nav-link">
                            <i class="nav-icon fas fa-square fa-fw"></i>
                            <p class="text-nowrap">Unit Offerings</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/locations")}}" class="nav-link">
                            <i class="nav-icon fas fa-map-marker fa-fw"></i>
                            <p class="text-nowrap">Locations</p>
                        </a>
                    </li>
                    </div>
                @endif
                @if(Auth::user()->roles->contains('id','1') || Auth::user()->roles->contains('id','1'))
                    <h4 class="brand-text text-white font-weight-light navBtn @if(Auth::user()->roles->contains('id','1')) navItem @endif" @if(Auth::user()->roles->contains('id','1')) boxName='administration'@endif">Administration</h4>
                    <div class="administration @if(Auth::user()->roles->contains('id','1')) closeNav @endif">
                    <li class="nav-item">
                        <a href="{{url("/users")}}" class="nav-link">
                            <i class="nav-icon fas fa-user-circle fa-fw"></i>
                            <p class="text-nowrap">Users</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/roles")}}" class="nav-link">
                            <i class="nav-icon fas fa-user-tag fa-fw"></i>
                            <p class="text-nowrap">Roles</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url("/permissions")}}" class="nav-link">
                            <i class="nav-icon fab fa-creative-commons-sampling-plus fa-fw"></i>
                            <p class="text-nowrap">Permissions</p>
                        </a>
                    </li>
                    </div>
                @endif
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
