@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Course - {{$course->course_code}}</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - The action of the form is the following route:
          Route::put('/courses/{course}', [CourseController::class, 'update'])->name('courses.update');
          This calls the update method of the CourseController to update our course.
          Notice it is a POST form but our route needs a PUT.... -->
        <form role="form" method="POST" action="{{ route('courses.update', $course) }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
        @csrf
        <!-- override the POST method with a PUT so we have a put method. We need to do this as browsers
                                do not support PUT via 'HTML form' submission -->
            @method('PUT')
            <div class="card-body">
                <div class="form-group">
                    <label for="id">Course ID</label>
                    <!-- input for id but we have disabled this so the user can not change it -->
                    <input type="number" class="form-control" name="id" id="id" value="{{ $course->id }}" disabled>
                </div>
                <div class="form-group">
                    <label for="course_code">Course Code</label>
                    <!-- input for the course code. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" maxlength="7" class="form-control" name="course_code" id="course_code" placeholder="Enter the course code..." value="{{($errors->any()) ? old('course_code') : $course->course_code}}" required>
                    @error('course_code')
                    <p class="text-danger">{{$errors->first('course_code')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="course_title">Course Title</label>
                    <!-- input for the course code. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" maxlength="191" class="form-control" name="course_title" id="course_title" placeholder="Enter the course title..." value="{{($errors->any()) ? old('course_title') : $course->course_title}}" required>
                    @error('course_title')
                    <p class="text-danger">{{$errors->first('course_title')}}</p>
                    @enderror
                </div>
                {{--
                <div class="form-group">
                    <label for="course_type">Course Type</label> -->
                    <!-- input for the course code. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                <!--
                    <input type="text" class="form-control" name="course_type" id="course_type" placeholder="Enter the course type..." value="{{($errors->any()) ? old('course_type') : $course->course_type}}" required>
                    @error('course_type')
                    <p class="text-danger">{{$errors->first('course_type')}}</p>
                    @enderror
                </div> --> --}}

                <div class="form-group">
                    <label for="course_type">Course Type</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select class="form-control" name="course_type" id="course_type" required>
                        <option value="Diploma" @if(old('course_type')=="Diploma" || $course->course_type=="Diploma" && !$errors->any())selected @endif>Diploma</option>
                        <option value="Advanced Diploma" @if(old('course_type')=="Advanced Diploma" || $course->course_type=="Advanced Diploma" && !$errors->any())selected @endif>Advanced Diploma</option>
                        <option value="Associate Degree" @if(old('course_type')=="Associate Degree" || $course->course_type=="Associate Degree" && !$errors->any())selected @endif>Associate Degree</option>
                        <option value="Bachelor Degree" @if(old('course_type')=="Bachelor Degree" || $course->course_type=="Bachelor Degree" && !$errors->any())selected @endif>Bachelor Degree</option>
                        <option value="Bachelor Honours Degree" @if(old('course_type')=="Bachelor Honours Degree" || $course->course_type=="Bachelor Honours Degree" && !$errors->any())selected @endif>Bachelor Honours Degree</option>
                        <option value="Graduate Certificate" @if(old('course_type')=="Graduate Certificate" || $course->course_type=="Graduate Certificate" && !$errors->any())selected @endif>Graduate Certificate</option>
                        <option value="Graduate Diploma" @if(old('course_type')=="Graduate Diploma" || $course->course_type=="Graduate Diploma" && !$errors->any())selected @endif>Graduate Diploma</option>
                        <option value="Masters Degree" @if(old('course_type')=="Masters Degree" || $course->course_type=="Masters Degree" && !$errors->any())selected @endif>Masters Degree</option>
                        <option value="Doctoral Degree" @if(old('course_type')=="Doctoral Degree" || $course->course_type=="Doctoral Degree" && !$errors->any())selected @endif>Doctoral Degree</option>
                    </select>
                    @error('course_type')
                    <p class="text-danger">{{$errors->first('course_type')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="credit_points">Credit Points</label>
                    <!-- input for the course code. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" class="form-control" name="credit_points" id="credit_points" placeholder="Enter the credit points..." value="{{($errors->any()) ? old('credit_points') : $course->credit_points}}" required>
                    @error('credit_points')
                    <p class="text-danger">{{$errors->first('credit_points')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="aqf_level">AQF Level</label>
                    <!-- input for the course code. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <select type="number" class="form-control" name="aqf_level" id="aqf_level" value="{{old('aqf_level')}}" required>
                        <option value="5" @if(old('aqf_level')=="5" || $course->aqf_level=="5" && !$errors->any())selected @endif>5</option>
                        <option value="6" @if(old('aqf_level')=="6" || $course->aqf_level=="6" && !$errors->any())selected @endif>6</option>
                        <option value="7" @if(old('aqf_level')=="7" || $course->aqf_level=="7" && !$errors->any())selected @endif>7</option>
                        <option value="8" @if(old('aqf_level')=="8" || $course->aqf_level=="8" && !$errors->any())selected @endif>8</option>
                        <option value="9" @if(old('aqf_level')=="9" || $course->aqf_level=="9" && !$errors->any())selected @endif>9</option>
                        <option value="10" @if(old('aqf_level')=="10" || $course->aqf_level=="10" && !$errors->any())selected @endif>10</option>
                    </select>
                    @error('aqf_level')
                    <p class="text-danger">{{$errors->first('aqf_level')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="units">Units</label><br>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    @foreach($units as $unit)
                        <span>{{$unit->unit_name}}</span>
                        <input type="checkbox" name="units[]" id="unit{{$unit->id}}" value="{{$unit->id}}" class="mr-4" @if($course->units->contains($unit)) checked @endif>
                    @endforeach
                    @error('units')
                    <p class="text-danger">{{$errors->first('units')}}</p>
                    @enderror
                </div>
                {{--
                <div class="form-group">
                    <label for="deleted">Deleted</label>
                    <!-- input for the course code. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" class="form-control" name="deleted" id="deleted" placeholder="Enter the Deleted..." value="{{($errors->any()) ? old('deleted') : $course->deleted}}">
                    @error('deleted')
                    <p class="text-danger">{{$errors->first('deleted')}}</p>
                    @enderror
                </div>
                --}}
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>

            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->



@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
