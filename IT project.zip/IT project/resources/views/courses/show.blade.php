@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')
    <h2>Course - {{$course->course_title}}</h2>
    <a href="{{route("courses")}}" class="btn btn-danger my-2">Back</a>
    <div class="card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Details</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped mb-4">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th>Course ID</th>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Course Type</th>
                    <th>Credit Points</th>
                    <th>AQF Level</th>
                    <!--<th>Deleted</th>-->
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the course id, course code, course title, course type, credit points, aqf level and deleted -->
                    <td>{{$course->id}}</td>
                    <td>{{$course->course_code}}</td>
                    <td>{{$course->course_title}}</td>
                    <td>{{$course->course_type}}</td>
                    <td>{{$course->credit_points}}</td>
                    <td>{{$course->aqf_level}}</td>
                    <!--<td>{{$course->deleted}}</td>-->
                    <td>
                        <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                        <form role="form" method="POST" action="{{ route('courses.destroy', $course) }}">
                            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                        @csrf
                        <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                        @method('DELETE')

                        <!-- Bootstrap button to edit the course. Once again, technically this does not need to be in the form. However I added it here
                        otherwise it would not be inline with the delete button. The link matches the name of the following route:
                        Route::get('/courses/{course}/edit', [CourseController::class, 'edit'])->name('courses.edit');
                        this route calls the edit function in CourseController and it will add the id of the course to the wildcard in the
                        endpoint-->
                            <a href="{{ route('courses.edit', $course) }}" class="btn btn-warning"
                               role="button">Edit</a>

                            <!-- Bootstrap button to delete the course. This button submits the form. If you look at the form action above you will see that the action calls
                            Route::delete('/courses/{course}/destroy', [CourseController::class, 'destroy'])->name('courses.destroy');
                            and it will add the id of the course to the wildcard in the endpoint-->
                            <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this course?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>

                </tbody>
            </table>
        </div>
    </div>
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Units</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if(count($course->units)==0)
                No units found.
            @elseif(count($course->units)>0)
                <table id="example1" class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Unit ID</th>
                        <th>Unit Code</th>
                        <th>Unit Name</th>
                        <th>Credit Points</th>
                        <th>AQF Level</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($course->units as $unit)
                        <tr>
                            <!-- show the unit id, unit code and unit name -->
                            <td>{{$unit->id}}</td>
                            <td>{{$unit->unit_code}}</td>
                            <td>{{$unit->unit_name}}</td>
                            <td>{{$unit->credit_points}}</td>
                            <td>{{$unit->aqf_level}}</td>
                            <td>
                                <a href="{{ route('units.show', $unit) }}" class="btn btn-success"
                                   role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            @endif
        </div>
    </div>
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Majors</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if(count($course->majors)==0)
                No majors found.
            @elseif(count($course->majors)>0)
                <table id="example1" class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Major ID</th>
                        <th>Major Name</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($course->majors as $major)
                        <tr>
                            <!-- show the major id and major name -->
                            <td>{{$major->id}}</td>
                            <td>{{$major->name}}</td>
                            <td>
                                <a href="{{ route('majors.show', $major) }}" class="btn btn-success"
                                   role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            @endif
        </div>
    </div>

    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Learning Outcomes</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if(count($course->learningOutcomes)==0)
                No units found.
            @elseif(count($course->learningOutcomes)>0)
                <table id="example1" class="table table-bordered table-striped mb-4">
                    <thead>
                        <tr>
                            <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                            <th>ID</th>
                            <th>Learning Outcome Code</th>
                            <th>Description</th>
                            <th>Type</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($course->learningOutcomes as $learningOutcome)
                            <tr>
                                <!-- show the staff id, name and code -->
                                <td>{{$learningOutcome->id}}</td>
                                <td>{{$learningOutcome->code}}</td>
                                <td>{{$learningOutcome->description}}</td>
                                <td>{{$learningOutcome->type}}</td>
                                <td>
                                    <!-- Bootstrap button to show the learning outcome -->
                                    <a href="{{ route('learningOutcomes.show', $learningOutcome) }}" class="btn btn-success" role="button">Show</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @endif
        </div>
    </div>

    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Add Learning Outcome</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
        <!-- /.card-header -->

        <!-- form start - notice it is a POST form as we are posting data. The action of the form is the following route:
         Route::post('/staff', [StaffController::class, 'store']);
         This calls the store method of the StaffController to store our new staff -->
        <form role="form" method="POST" action="{{ route('learningOutcomes') }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
            @csrf
            <div class="card-body">
                <div class="form-group">
                    <label for="code">Learning Outcome Code</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="code" id="code" placeholder="Enter the Learning Outcome Code..." value="{{old('code')}}" required>
                    @error('code')
                    <p class="danger">{{$errors->first('code')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="description" id="description" placeholder="Enter the Description..." value="{{old('description')}}" required>
                    @error('description')
                    <p class="text-danger">{{$errors->first('description')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="type">Type</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select class="form-control" name="type" id="type" value="Course" required>
                        <option value="Course">Course</option>
                    </select>

                </div>
                <div class="form-group" id="course_div">
                    <label for="course_id">Course</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->

                    <select class="form-control" id="course_id" name="course_id" value="{{old('course_id')}}">

                        <option value="{{$course->id}}">{{$course->course_title}}</option>

                    </select>
                    @error('course_id')
                    <p class="danger">{{$errors->first('course_id')}}</p>
                    @enderror


                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            <!-- /.card-body -->
        </form>


    </div>
    </div>

    <!-- /.card -->


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
