@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">New Course</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - notice it is a POST form as we are posting data. The action of the form is the following route:
         Route::post('/courses', [CourseController::class, 'store']);
         This calls the store method of the CourseController to store our new course -->
        <form role="form" method="POST" action="{{ route('courses') }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
            @csrf
            <div class="card-body">
                <div class="form-group">
                    <label for="course_code">Course Code</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the courses table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="7" class="form-control" name="course_code" id="course_code" placeholder="Enter the course code..." value="{{old('course_code')}}" required>
                    @error('course_code')
                    <p class="text-danger">{{$errors->first('course_code')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="course_title">Course Title</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the courses table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="course_title" id="course_title" placeholder="Enter the course title..." value="{{old('course_title')}}" required>
                    @error('course_title')
                    <p class="text-danger">{{$errors->first('course_title')}}</p>
                    @enderror
                </div>
                {{--
                <div class="form-group">
                    <label for="course_type">Course Type</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the courses table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                <!--
                    <input type="text" class="form-control" name="course_type" id="course_type" placeholder="Enter the course type..." value="{{old('course_type')}}" required>
                    @error('course_type')
                    <p class="danger">{{$errors->first('course_type')}}</p>
                    @enderror
                </div> --}}

                <div class="form-group">
                    <label for="course_type">Course Type</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the courses table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select class="form-control" name="course_type" id="course_type" required>
                        <option value="Diploma" @if(old('course_type')=="Diploma")selected @endif>Diploma</option>
                        <option value="Advanced Diploma" @if(old('course_type')=="Advanced Diploma")selected @endif>Advanced Diploma</option>
                        <option value="Associate Degree" @if(old('course_type')=="Associate Degree")selected @endif>Associate Degree</option>
                        <option value="Bachelor Degree" @if(old('course_type')=="Bachelor Degree")selected @endif>Bachelor Degree</option>
                        <option value="Bachelor Honours Degree" @if(old('course_type')=="Bachelor Honours Degree")selected @endif>Bachelor Honours Degree</option>
                        <option value="Graduate Certificate" @if(old('course_type')=="Graduate Certificate")selected @endif>Graduate Certificate</option>
                        <option value="Graduate Diploma" @if(old('course_type')=="Graduate Diploma")selected @endif>Graduate Diploma</option>
                        <option value="Masters Degree" @if(old('course_type')=="Masters Degree")selected @endif>Masters Degree</option>
                        <option value="Doctoral Degree" @if(old('course_type')=="Doctoral Degree")selected @endif>Doctoral Degree</option>
                    </select>
                    @error('course_type')
                    <p class="text-danger">{{$errors->first('course_type')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="credit_points">Credit Points</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the courses table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" class="form-control" name="credit_points" id="credit_points" placeholder="Enter the credit points..." value="{{old('credit_points')}}" required>
                    @error('credit_points')
                    <p class="text-danger">{{$errors->first('credit_points')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="aqf_level">AQF Level</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the courses table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select type="number" class="form-control" name="aqf_level" id="aqf_level" value="{{old('aqf_level')}}" required>
                        <option value="5" @if(old('aqf_level')=="5")selected @endif>5</option>
                        <option value="6" @if(old('aqf_level')=="6")selected @endif>6</option>
                        <option value="7" @if(old('aqf_level')=="7")selected @endif>7</option>
                        <option value="8" @if(old('aqf_level')=="8")selected @endif>8</option>
                        <option value="9" @if(old('aqf_level')=="9")selected @endif>9</option>
                        <option value="10" @if(old('aqf_level')=="10")selected @endif>10</option>
                    </select>
                    @error('aqf_level')
                    <p class="text-danger">{{$errors->first('aqf_level')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="units">Units</label><br>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    @foreach($units as $unit)
                        <span>{{$unit->unit_name}}</span>
                        <select name="units[]" id="units{{$unit->id}}" class="mr-4">
                            <option value=></option>
                            <option value="{{$unit->id}}_Core">Core</option>
                            <option value="{{$unit->id}}_Elective">Elective</option>
                        </select>

                    @endforeach
                    @error('units')
                    <p class="text-danger">{{$errors->first('units')}}</p>
                    @enderror
                </div>
                {{--
                <div class="form-group">
                    <label for="deleted">Deleted</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the courses table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" class="form-control" name="deleted" id="deleted" placeholder="Enter the deleted..." value="{{old('deleted')}}">
                    @error('deleted')
                    <p class="danger">{{$errors->first('deleted')}}</p>
                    @enderror
                </div> --}}

            <!-- submit the form -->
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
    <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
