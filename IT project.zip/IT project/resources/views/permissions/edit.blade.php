@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Permission - {{$permission->permission_name}}</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - The action of the form is the following route:
         Route::put('/permissions/{permission}', [PermissionController::class, 'update'])->name('permissions.update');
         This calls the update method of the permissionController to update our Permission.
         Notice it is a POST form but our route needs a PUT.... -->
        <form role="form" method="POST" action="{{ route('permissions.update', $permission) }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
        @csrf
        <!-- override the POST method with a PUT so we have a put method. We need to do this as browsers
                                do not support PUT via 'HTML form' submission -->
            @method('PUT')
            <div class="card-body">
                <div class="form-group">
                    <label for="id">Permission ID</label>
                    <!-- input for id but we have disabled this so the user can not change it -->
                    <input type="number" class="form-control" name="id" id="id" value="{{ ($errors->any()) ? old('id') : $permission->id }}" disabled>
                </div>
                <div class="form-group">
                    <label for="permission_name">Permission Name</label>
                    <!-- input for the Permission name. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" maxlength="191" class="form-control" name="permission_name" id="permission_name" placeholder="Enter the Permission Name..." value="{{($errors->any()) ? old('permission_name') : $permission->permission_name}}" required>
                </div>
                <div class="form-group">
                    <label for="permission_function">Permission Function</label>
                    <!-- input for the Permission function. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" maxlength="191" class="form-control" name="permission_function" id="permission_function" placeholder="Enter the Permission Function..." value="{{($errors->any()) ? old('permission_function') : $permission->permission_function}}" required>
                </div>

                <div class="form-group">
                    <label for="permission_description">Permission Description</label>
                    <!-- input for the Permission description. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" maxlength="191" class="form-control" name="permission_description" id="permission_description" placeholder="Enter the Permission Description..." value="{{($errors->any()) ? old('permission_description') : $permission->permission_description}}" required>
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
