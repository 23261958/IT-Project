@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')
    <h2>Permission - {{$permission->permission_name}}</h2>
    <a href="{{route("permissions")}}" class="btn btn-danger my-2">Back</a>
    <div class="card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Details</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th>ID</th>
                    <th>Permission Name</th>
                    <th>Permission Function</th>
                    <th>Permission Description</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the competency id, name and code -->
                    <td>{{$permission->id}}</td>
                    <td>{{$permission->permission_name}}</td>
                    <td>{{$permission->permission_function}}</td>
                    <td>{{$permission->permission_description}}</td>
                    <td>
                        <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                        <form role="form" method="POST" action="{{ route('permissions.destroy', $permission) }}">
                            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                        @csrf
                        <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                        @method('DELETE')

                        <!-- Bootstrap button to edit the unit. Once again, technically this does not need to be in the form. However I added it here
                        otherwise it would not be inline with the delete button. The link matches the name of the following route:
                                Route::get('/permissions/{permission}/edit', [PermissionController::class, 'show'])->name('permissions.edit');
                        this route calls the edit function in PermissionController and it will add the id of the permission to the wildcard in the
                        endpoint-->
                            <a href="{{ route('permissions.edit', $permission) }}" class="btn btn-warning"
                               role="button">Edit</a>

                            <!-- Bootstrap button to delete the unit. This button submits the form. If you look at the form action above you will see that the action calls
                                    Route::delete('/permissions/{permission}/destroy', [PermissionController::class, 'destroy'])->name('permissions.destroy');
                            and it will add the id of the permission to the wildcard in the endpoint-->
                            <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this permission?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>

                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Roles</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if (count($permission->roles) == 0)
                No roles found
            @elseif (count($permission->roles) > 0)
            <!-- yes we have roles so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Role ID</th>
                        <th>Role Name</th>
                        <th>Permissions Assigned</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- using a blade foreach loop to loop through the roles - https://laravel.com/docs/7.x/blade#loops -->
                    @foreach ($permission->roles as $role)
                        <tr>
                            <!-- show the role id, and role name -->
                            <td>{{$role->id}}</td>
                            <td>{{$role->role_name}}</td>
                            <td>{{$role->permissions->count()}}</td>
                            <td>
                                <a href="{{ route('roles.show', $role) }}" class="btn btn-success" role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Role ID</th>
                        <th>Role Name</th>
                        <th>Permissions Assigned</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>

            @endif
        </div>
    </div>
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Users</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if (count($permission->users()) == 0)
                No users found
            @elseif (count($permission->users()) > 0)
            <!-- yes we have users so create a table. I am using the table-bordered and table striped
                styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                <table class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Roles Assigned</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- using a blade foreach loop to loop through the users - https://laravel.com/docs/7.x/blade#loops -->
                    @foreach ($permission->users() as $user)
                        <tr>
                            <!-- show the user id, user code, user title, user type, credit points, aqf level and deleted -->
                            <td>{{$user->id}}</td>
                            <td>{{$user->name}}</td>
                            <td>{{$user->email}}</td>
                            <td>{{($user->password) ? 'Hashed Value' : ''}}</td>
                            <td>{{$user->roles->count()}}</td>
                            <td>{{$user->created_at}}</td>
                            <td>{{$user->updated_at}}</td>
                            <td>
                                <a href="{{ route('users.show', $user) }}" class="btn btn-success" role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Roles Assigned</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>

            @endif

        </div>
    </div>
@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
