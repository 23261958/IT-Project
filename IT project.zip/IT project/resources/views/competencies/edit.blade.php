@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Competency - {{$competency->description}}</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - The action of the form is the following route:
         Route::put('/competencies/{competency}', [CompetencyController::class, 'update'])->name('competencies.update');
         This calls the update method of the CompetencyController to update our competency.
         Notice it is a POST form but our route needs a PUT.... -->
        <form role="form" method="POST" action="{{ route('competencies.update', $competency) }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
        @csrf
        <!-- override the POST method with a PUT so we have a put method. We need to do this as browsers
                                do not support PUT via 'HTML form' submission -->
            @method('PUT')
            <div class="card-body">
                <div class="form-group">
                    <label for="id">ID</label>
                    <!-- input for id but we have disabled this so the user can not change it -->
                    <input type="number" class="form-control" name="id" id="id" value="{{ ($errors->any()) ? old('id') : $competency->id }}" disabled>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <!-- input for the description. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <input type="text" maxlength="191" class="form-control" name="description" id="description" placeholder="Enter the Description..." value="{{($errors->any()) ? old('description') : $competency->description}}" required>
                </div>
                <div class="form-group">
                    <label for="type">Type</label>
                    <!-- input for the Type. Notice it is required so we can validate that a user has entered it as this field is not nullable in the database -->
                    <select class="form-control" name="type" id="type" value="{{($errors->any()) ? old('type') : $competency->type}}" required>
                        <option value="Not applicable(0)" {{($competency->type=="0") ? "selected" : ""}}>Not applicable(0)</option>
                        <option value="Not very well (1)" {{($competency->type=="1") ? "selected" : ""}}>Not very well (1)</option>
                        <option value="Well(2)" {{($competency->type=="2") ? "selected" : ""}}>Well(2)</option>
                        <option value="Outstanding (3)" {{($competency->type=="3") ? "selected" : ""}}>Outstanding (3)</option>

                    </select>
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
