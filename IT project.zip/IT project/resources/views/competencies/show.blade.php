@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')
    <h2>Competency - {{$competency->description}}</h2>
    <a href="{{route("competencies")}}" class="btn btn-danger my-2">Back</a>
    <div class="card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Details</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th>ID</th>
                    <th>Description</th>
                    <th>Type</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the competency id, name and code -->
                    <td>{{$competency->id}}</td>
                    <td>{{$competency->description}}</td>
                    <td>{{$competency->type}}</td>
                    <td>
                        <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                        <form role="form" method="POST" action="{{ route('competencies.destroy', $competency) }}">
                            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                        @csrf
                        <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                        @method('DELETE')

                        <!-- Bootstrap button to edit the unit. Once again, technically this does not need to be in the form. However I added it here
                        otherwise it would not be inline with the delete button. The link matches the name of the following route:
                        Route::get('/competencies/{competency}/edit', [CompetencyController::class, 'edit'])->name('competencies.edit');
                        this route calls the edit function in CompetencyController and it will add the id of the competency to the wildcard in the
                        endpoint-->
                            <a href="{{ route('competencies.edit', $competency) }}" class="btn btn-warning"
                               role="button">Edit</a>

                            <!-- Bootstrap button to delete the unit. This button submits the form. If you look at the form action above you will see that the action calls
                            Route::delete('/competencies/{competency}/destroy', [CompetencyController::class, 'destroy'])->name('competencies.destroy');
                            and it will add the id of the competency to the wildcard in the endpoint-->
                            <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this competency?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>

                </tbody>
            </table>
        </div>
    </div>
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Learning Outcomes</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if(count($competency->learningOutcomes) == 0)
                No Learning outcome found
            @elseif(count($competency->learningOutcomes) > 0)
                <table class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Learning Outcome ID</th>
                        <th>Description</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($competency->learningOutcomes as $learningOutcome)
                        <tr>
                            <!-- show the location id, name and code -->
                            <td>{{$learningOutcome->id}}</td>
                            <td>{{$learningOutcome->description}}</td>
                            <td>
                                <a href="{{ route('learningOutcomes.show', $learningOutcome) }}" class="btn btn-success"
                                   role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                    <tfoot>
                    <th>Learning Outcome ID</th>
                    <th>Description</th>
                    <th></th>
                    </tfoot>
                </table>
            @endif
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->

@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
