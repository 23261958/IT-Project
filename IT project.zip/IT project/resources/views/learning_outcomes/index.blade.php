@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
    <!-- DataTables -->
    <link rel="stylesheet" href="{{ asset("plugins/datatables-bs4/css/dataTables.bootstrap4.min.css") }}">
    <link rel="stylesheet" href="{{ asset("plugins/datatables-responsive/css/responsive.bootstrap4.min.css") }}">
    <link rel="stylesheet" href="{{ asset("plugins/datatables-buttons/css/buttons.bootstrap4.min.css") }}">

@endsection

@section('contentBody')

    <!-- using a Bootstrap button (see https://getbootstrap.com/docs/4.0/components/buttons/) as a link to go to the staff.create route.
    The link matches the name of the following route:
    Route::get('/staff/create', [StaffController::class, 'create'])->name('staff.create');
    this route calls the create function in the StaffController  -->
    <a class="btn btn-primary" href="{{ route('learningOutcomes.create') }}" role="button">New Learning Outcome</a>

    <br><br>


    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">All Learning Outcomes</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <!-- using a blade if statement to see if we have any staff to show, see
             https://laravel.com/docs/7.x/blade#if-statements -->
            @if (count($learning) == 0)
                No learning outcome found
            @elseif (count($learning) > 0)
            <!-- yes we have staff so create a table. I am using the table-bordered and table striped
              styles from bootstrap - https://getbootstrap.com/docs/4.0/content/tables/ -->
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>ID</th>
                        <th>Learning Outcome Code</th>
                        <th>Description</th>
                        <th>Type</th>
                        <th>Unit</th>
                        <th>Course</th>
                        <th>Major</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- using a blade foreach loop to loop through the staff - https://laravel.com/docs/7.x/blade#loops -->
                    @foreach ($learning as $learnOutcome)
                        <tr>
                            <!-- show the staff member id, name and code -->
                            <td>{{$learnOutcome->id}}</td>
                            <td>{{$learnOutcome->code}}</td>
                            <td>{{$learnOutcome->description}}</td>
                            <td>{{$learnOutcome->type}}</td>
                            <td>@if($learnOutcome->unit){{$learnOutcome->unit->unit_name}}@endif</td>
                            <td>@if($learnOutcome->course){{$learnOutcome->course->course_title}}@endif</td>
                            <td>@if($learnOutcome->major){{$learnOutcome->major->name}}@endif</td>


                            <td>
                                <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                                <form role="form" method="POST" action="{{ route('learningOutcomes.destroy', $learnOutcome) }}">
                                    <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                                @csrf
                                <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                                    @method('DELETE')

                                <!-- Bootstrap button to show the staff member. Technically this does not need to be in the form. However I added it here
                                otherwise it would not be inline with the delete button. The link matches the name of the following route:
                                Route::get('/staff/{staff member}/show', [StaffController::class, 'show'])->name('staff.show');
                                this route calls the show function in StaffController and it will add the id of the staff to the wildcard in the
                                endpoint-->
                                    <a href="{{ route('learningOutcomes.show', $learnOutcome) }}" class="btn btn-success"
                                       role="button">Show</a>

                                    <!-- Bootstrap button to edit the staff member. Once again, technically this does not need to be in the form. However I added it here
                                otherwise it would not be inline with the delete button. The link matches the name of the following route:
                                Route::get('/staff/{staff member}/edit', [StaffController::class, 'edit'])->name('staff.edit');
                                this route calls the edit function in StaffController and it will add the id of the staff member to the wildcard in the
                                endpoint-->
                                    <a href="{{ route('learningOutcomes.edit', $learnOutcome) }}" class="btn btn-warning"
                                       role="button">Edit</a>

                                    <!-- Bootstrap button to delete the staff member. This button submits the form. If you look at the form action above you will see that the action calls
                                    Route::delete('/staff/{staff member}/destroy', [StaffController::class, 'destroy'])->name('staff.destroy');
                                    and it will add the id of the staff member to the wildcard in the endpoint-->
                                    <button type="submit" class="btn btn-danger"
                                            onclick="return confirm('Are you sure you want to delete this learning outcome?')">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Learning Outcome Code</th>
                        <th>Description</th>
                        <th>Type</th>
                        <th>Unit</th>
                        <th>Course</th>
                        <th>Major</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>

            @endif

        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->


    <!-- The Modal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body" id="modalBody">
            Modal body..
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>

        </div>
        </div>
    </div>

@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
    <script src="{{ asset("plugins/datatables/jquery.dataTables.min.js") }}"></script>
    <script src="{{ asset("plugins/datatables-bs4/js/dataTables.bootstrap4.min.js") }}"></script>
    <script src="{{ asset("plugins/datatables-responsive/js/dataTables.responsive.min.js") }}"></script>
    <script src="{{ asset("plugins/datatables-responsive/js/responsive.bootstrap4.min.js") }}"></script>
    <script>
        $(function () {
            $("#example1").DataTable({
                "autoWidth": true,
            });

        });

        // Display alert message when a new record was added.
        var msgAdd = '{{Session::get('alertAdd')}}';
        var existAdd = '{{Session::has('alertAdd')}}';
        if(existAdd){
            if(msgAdd=="1")
            {
                $("#modalBody").html("Successfully Added!");
                $('#myModal').modal('show');
            }
            else
            {
                $("#modalBody").html("Adding Failed!");
                $('#myModal').modal('show');
            }
        }

        // Display alert message when a record was edited.
        var msgEdit = '{{Session::get('alertEdit')}}';
        var existEdit = '{{Session::has('alertEdit')}}';
        if(existEdit){
            if(msgEdit=="1")
            {
                $("#modalBody").html("Successfully Edited!");
                $('#myModal').modal('show');
            }
            else
            {
                $("#modalBody").html("Edit Failed!");
                $('#myModal').modal('show');
            }
        }

        // Display alert message when a record was deleted.
        var msgDelete = '{{Session::get('alertDelete')}}';
        var existDelete = '{{Session::has('alertDelete')}}';
        if(existDelete){
            if(msgDelete=="1")
            {
                $("#modalBody").html("Successfully Deleted!");
                $('#myModal').modal('show');
            }
            else
            {
                $("#modalBody").html("Delete Failed!");
                $('#myModal').modal('show');
            }
        }

    </script>
@endsection
