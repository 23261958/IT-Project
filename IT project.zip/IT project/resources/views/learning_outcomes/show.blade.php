@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')
    <h2>Learning Outcome - {{$learningOutcome->code}}</h2>
    <a href="{{route("learningOutcomes")}}" class="btn btn-danger my-2">Back</a>
    <div class="card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Details</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped mb-4">
                <thead>
                <tr>
                    <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                    <th>ID</th>
                    <th>Learning Outcome Code</th>
                    <th>Description</th>
                    <th>Type</th>
                    <th>Unit</th>
                    <th>Course</th>
                    <th>Major</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the staff id, name and code -->
                    <td>{{$learningOutcome->id}}</td>
                    <td>{{$learningOutcome->code}}</td>
                    <td>{{$learningOutcome->description}}</td>
                    <td>{{$learningOutcome->type}}</td>
                    <td>@if($learningOutcome->unit){{$learningOutcome->unit->unit_name}}@endif</td>
                    <td>@if($learningOutcome->course){{$learningOutcome->course->course_title}}@endif</td>
                    <td>@if($learningOutcome->major){{$learningOutcome->major->name}}@endif</td>
                    <td>
                        <!-- we need to put the delete button in a form with a POST method or it will send a get request, not a delete request -->
                        <form role="form" method="POST" action="{{ route('learningOutcomes.destroy', $learningOutcome) }}">
                            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
                        @csrf
                        <!-- override the POST method with a DELETE so we have a delete method. We need to do this as browsers
                                do not support DELETE via 'HTML form' submission -->
                        @method('DELETE')

                           <!-- Bootstrap button to edit the staff. Once again, technically this does not need to be in the form. However I added it here
                        otherwise it would not be inline with the delete button. The link matches the name of the following route:
                        Route::get('/staff/{staff}/edit', [StaffController::class, 'edit'])->name('staff.edit');
                        this route calls the edit function in StaffController and it will add the id of the staff to the wildcard in the
                        endpoint-->
                            <a href="{{ route('learningOutcomes.edit', $learningOutcome) }}" class="btn btn-warning"
                               role="button">Edit</a>

                            <!-- Bootstrap button to delete the staff. This button submits the form. If you look at the form action above you will see that the action calls
                            Route::delete('/staff/{staff}/destroy', [StaffController::class, 'destroy'])->name('staff.destroy');
                            and it will add the id of the staff to the wildcard in the endpoint-->
                            <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this learning outcome?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>

                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">
                @switch($learningOutcome->type)
                    @case('Course')Course @break
                    @case('Major')Major @break
                    @case('Unit')Unit @break
                @endswitch
            </h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
                @switch($learningOutcome->type)
                @case('Course')
                <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Course ID</th>
                        <th>Course Code</th>
                        <th>Course Title</th>
                        <th>Course Type</th>
                        <th>Credit Points</th>
                        <th>AQF Level</th>
                        <!--<th>Deleted</th>-->
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <tr>
                    <!-- show the course id, course code, course title, course type, credit points, aqf level and deleted -->
                    <td>{{$learningOutcome->course->id}}</td>
                    <td>{{$learningOutcome->course->course_code}}</td>
                    <td>{{$learningOutcome->course->course_title}}</td>
                    <td>{{$learningOutcome->course->course_type}}</td>
                    <td>{{$learningOutcome->course->credit_points}}</td>
                    <td>{{$learningOutcome->course->aqf_level}}</td>
                <!--<td>{{$learningOutcome->course->deleted}}</td>-->
                    <td>
                        <a href="{{ route('courses.show', $learningOutcome->course) }}" class="btn btn-success" role="button">Show</a>
                    </td>
                </tr>

                </tbody>
                @break
                @case('Major')
                <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Major Id</th>
                        <th>Course Id</th>
                        <th>Name</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <!-- show the major id, course id and major name -->
                        <td>{{$learningOutcome->major->id}}</td>
                        <td>{{$learningOutcome->major->course_id}}</td>
                        <td>{{$learningOutcome->major->name}}</td>

                        <td>
                            <a href="{{ route('majors.show', $learningOutcome->major) }}" class="btn btn-success"
                               role="button">Show</a>
                        </td>
                    </tr>

                    </tbody>
                @break
                @case('Unit')
                <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Unit ID</th>
                        <th>Unit Code</th>
                        <th>Unit Name</th>
                        <th>Credit Points</th>
                        <th>AQF Level</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <!-- show the unit id, name and code -->
                        <td>{{$learningOutcome->unit->id}}</td>
                        <td>{{$learningOutcome->unit->unit_code}}</td>
                        <td>{{$learningOutcome->unit->unit_name}}</td>
                        <td>{{$learningOutcome->unit->credit_points}}</td>
                        <td>{{$learningOutcome->unit->aqf_level}}</td>
                        <td>
                            <a href="{{ route('units.show', $learningOutcome->unit) }}" class="btn btn-success"
                               role="button">Show</a>
                        </td>
                    </tr>

                    </tbody>
                @break
                @endswitch
            </table>
        </div>
    </div>
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Linked Competencies</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        <div class="card-body">
            @if(count($learningOutcome->competencies) == 0)
                No linked competencies found
            @elseif(count($learningOutcome->competencies) > 0)
                <table class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>Competency ID</th>
                        <th>Description</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($learningOutcome->competencies as $competency)
                        <tr>
                            <!-- show the location id, name and code -->
                            <td>{{$competency->id}}</td>
                            <td>{{$competency->description}}</td>
                            <td>
                                <a href="{{ route('competencies.show', $competency) }}" class="btn btn-success"
                                   role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                    <tfoot>
                    <th>Competency ID</th>
                    <th>Description</th>
                    <th></th>
                    </tfoot>
                </table>
            @endif
        </div>
        <!-- /.card-body -->
    </div>
    <div class="card collapsed-card">
        <div class="card-header" data-card-widget="collapse">
            <h3 class="card-title">Linked Learning Outcomes</h3>
            <div class="card-tools pull-right">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        @php
            $learningOutcomes = $learningOutcome->learningOutcomes1->merge($learningOutcome->learningOutcomes2)->unique();
        @endphp
        <div class="card-body">
            @if(count($learningOutcomes) == 0)
                No linked learning outcomes found.
            @elseif(count($learningOutcomes) > 0)
                <table class="table table-bordered table-striped mb-4">
                    <thead>
                    <tr>
                        <!-- we would not normally show the id however I put it in there so you can see that it is autocreated -->
                        <th>ID</th>
                        <th>Code</th>
                        <th>Description</th>
                        <th>Type</th>
                        <th>Unit</th>
                        <th>Course</th>
                        <th>Major</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($learningOutcomes as $lo)
                        <tr>
                            <!-- show the location id, name and code -->
                            <td>{{$lo->id}}</td>
                            <td>{{$lo->code}}</td>
                            <td>{{$lo->description}}</td>
                            <td>{{$lo->type}}</td>
                            <td>@if($lo->unit){{$lo->unit->unit_name}}@endif</td>
                            <td>@if($lo->course){{$lo->course->course_title}}@endif</td>
                            <td>@if($lo->major){{$lo->major->name}}@endif</td>
                            <td>
                                <a href="{{ route('learningOutcomes.show', $lo) }}" class="btn btn-success"
                                   role="button">Show</a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                    <tfoot>
                    <th>ID</th>
                    <th>Code</th>
                    <th>Description</th>
                    <th>Type</th>
                    <th>Unit</th>
                    <th>Course</th>
                    <th>Major</th>
                    <th></th>
                    </tfoot>
                </table>
            @endif
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
