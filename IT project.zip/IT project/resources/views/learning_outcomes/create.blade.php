@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">New Learning Outcome</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - notice it is a POST form as we are posting data. The action of the form is the following route:
         Route::post('/staff', [StaffController::class, 'store']);
         This calls the store method of the StaffController to store our new staff -->
        <form role="form" method="POST" action="{{ route('learningOutcomes') }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
            @csrf
            <div class="card-body">
                <div class="form-group">
                    <label for="code">Learning Outcome Code</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="code" id="code" placeholder="Enter the Learning Outcome Code..." value="{{old('code')}}" required>
                    @error('code')
                        <p class="danger">{{$errors->first('code')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="description" id="description" placeholder="Enter the Description..." value="{{old('description')}}" required>
                    @error('description')
                        <p class="text-danger">{{$errors->first('description')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="type">Type</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the staff table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <select class="form-control" onchange="checkType()" name="type" id="type" value="{{old('type')}}" required>
                        <option value="Unit">Unit</option>
                        <option value="Course">Course</option>
                        <option value="Major">Major</option>
                    </select>
                    @error('type')
                        <p class="text-danger">{{$errors->first('type')}}</p>
                    @enderror
                </div>
                <div class="form-group" id="unit_div">
                    <label for="unit_id">Unit</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->

                    <select class="form-control" id="unit_id" name="unit_id" value="{{old('unit_id')}}">
                        @foreach($units as $unit)
                            <option value="{{$unit->id}}">{{$unit->unit_name}}</option>
                        @endforeach
                    </select>
                    @error('unit_id')
                    <p class="danger">{{$errors->first('unit_id')}}</p>
                    @enderror


                </div>
                <div class="form-group" id="course_div" style="display: none">
                    <label for="course_id">Course</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->

                    <select class="form-control" id="course_id" name="course_id" value="{{old('course_id')}}">
                        @foreach($courses as $course)
                            <option value="{{$course->id}}">{{$course->course_title}}</option>
                        @endforeach
                    </select>
                    @error('course_id')
                    <p class="danger">{{$errors->first('course_id')}}</p>
                    @enderror


                </div>
                <div class="form-group" id="major_div" style="display: none">
                    <label for="major_id">Major</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->

                    <select class="form-control" id="major_id" name="major_id" value="{{old('major_id')}}">
                        @foreach($majors as $major)
                            <option value="{{$major->id}}">{{$major->name}}</option>
                        @endforeach
                    </select>
                    @error('major_id')
                    <p class="danger">{{$errors->first('major_id')}}</p>
                    @enderror
                </div>

                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->


    <script>

        function checkType() {
            switch(document.getElementById('type').value) {
                case 'Unit':
                        document.getElementById('unit_div').style.display="block";
                        document.getElementById('course_div').style.display="none";
                        document.getElementById('major_div').style.display="none"

                        document.getElementById('course_id').value=null;
                        document.getElementById('major_id').value=null;

                    break;
                case 'Course':
                        document.getElementById('course_div').style.display="block";
                        document.getElementById('unit_div').style.display="none";
                        document.getElementById('major_div').style.display="none";

                        document.getElementById('unit_id').value=null;
                        document.getElementById('major_id').value=null;



                    break;

                case 'Major':
                        document.getElementById('major_div').style.display="block";
                        document.getElementById('unit_div').style.display="none";
                        document.getElementById('course_div').style.display="none";

                        document.getElementById('unit_id').value=null;
                        document.getElementById('course_id').value=null;
            }


            }

    </script>



@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
