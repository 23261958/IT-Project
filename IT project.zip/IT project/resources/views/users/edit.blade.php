@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit User - {{$user->name}}</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - The action of the form is the following route:
          Route::put('/users/{user}', [UserController::class, 'update'])->name('users.update');
          This calls the update method of the UserController to update our user.
          Notice it is a POST form but our route needs a PUT.... -->
        <form role="form" method="POST" action="{{ route('users.update', $user) }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
        @csrf
        <!-- override the POST method with a PUT so we have a put method. We need to do this as browsers
                                do not support PUT via 'HTML form' submission -->
            @method('PUT')
            <div class="card-body">
                <div class="form-group">
                    <label for="name">Name</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="name" id="name" placeholder="Enter the user name..." value="{{($errors->any()) ? old('name') : $user->name}}" required>
                    @error('name')
                        <p class="text-danger">{{$errors->first('name')}}</p>
                    @enderror
                </div>
                <div class="form-group" onload="checkConfirmEmail()">
                    <label for="email">Email</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" onchange="checkConfirmEmail()" class="form-control" name="email" id="email" placeholder="Enter the user email address..." value="{{($errors->any()) ? old('email') : $user->email}}" required>
                    @error('email')
                        <p class="text-danger">{{$errors->first('email')}}</p>
                    @enderror
                </div>
                <div class="form-group" id="emailConfirmDiv" style="display:{{($errors->has('email')) ? "block" : "none"}}">
                    <label for="email_confirmation">Confirm Email</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="email_confirmation" id="email_confirmation" placeholder="Confirm the user email address..." value="{{($errors->any()) ? old('email_confirmation') : $user->email}}" required>
                    @error('email_confirmation')
                        <p class="text-danger">{{$errors->first('email_confirmation')}}</p>
                    @enderror
                </div>
                <div class="form-group" onload="checkConfirmPassword()">
                    <label for="password">Password</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="password" maxlength="191" onchange="checkConfirmPassword()" class="form-control" name="password" id="password" placeholder="Leave blank if no change to password." value="{{($errors->has('password')) ? "" : old('password')}}">
                    @error('password')
                        <p class="text-danger">{{$errors->first('password')}}</p>
                    @enderror
                </div>
                <div class="form-group" id="passwordConfirmDiv" style="display:{{($errors->any()) ? "block" : "none"}}">
                    <label for="password_confirmation">Confirm Password</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="password" maxlength="191" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm the user password..." value="{{($errors->has('password')) ? "" : old('password_confirmation')}}">
                    @error('password_confirmation')
                        <p class="text-danger">{{$errors->first('password_confirmation')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="roles">Roles</label><br>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    @foreach($roles as $role)
                        <span>{{$role->role_name}}</span>
                        <input type="checkbox" name="roles[]" id="role{{$role->id}}" value="{{$role->id}}" class="mr-4" @if($user->roles->contains($role)) checked @endif>
                    @endforeach
                    @error('roles')
                    <p class="text-danger">{{$errors->first('roles')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->
    <script>
        function checkConfirmEmail() {
            var oldEmail = "{{$user->email}}";
            var newEmail = document.getElementById("email").value;
            if (oldEmail != newEmail) {
                document.getElementById("emailConfirmDiv").style.display="block";
            } else {
                document.getElementById("emailConfirmDiv").style.display="none";
                document.getElementById("emailConfirmDiv").value="{{$user->email}}";
            }
        }

        function checkConfirmPassword() {
            var oldPassword = "{{$user->password}}";
            var newPassword = document.getElementById("password").value;
            if (oldPassword != newPassword) {
                document.getElementById("passwordConfirmDiv").style.display="block";
            } else {
                document.getElementById("passwordConfirmDiv").style.display="none";
                document.getElementById("passwordConfirmDiv").value="{{$user->password}}";
            }
        }
    </script>


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
