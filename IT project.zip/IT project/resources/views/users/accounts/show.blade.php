@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
    <link rel="stylesheet" href="{{ asset("plugins/datatables-bs4/css/dataTables.bootstrap4.min.css") }}">
    <link rel="stylesheet" href="{{ asset("plugins/datatables-responsive/css/responsive.bootstrap4.min.css") }}">
    <link rel="stylesheet" href="{{ asset("plugins/datatables-buttons/css/buttons.bootstrap4.min.css") }}">
@endsection

@section('contentBody')

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 mx-auto">

    <div class="card card-primary card-outline">
        <div class="card-body box-profile">


            <h3 class="profile-username text-center">{{$user->name}}</h3>

            @if (count($user->roles) == 0)
                <p>No Roles Found</p>
                @endif

            <div class="text-muted text-center" style="text-align: center">
                @foreach($user->roles as $role)
                    {{$role->role_name}}
                    @if( !$loop->last)
                        ,
                    @endif

                @endforeach
            </div>
            <ul class="list-group list-group-unbordered mb-3">
                <li class="list-group-item">
                    <b>User Id</b> <span class="float-right">{{$user->id}}</span>
                </li>
                <li class="list-group-item">
                    <b>Name</b> <span class="float-right">{{$user->name}}</span>
                </li>
                <li class="list-group-item">
                    <b>Email</b> <span class="float-right">{{$user->email}}</span>
                </li>




            </ul>

            <!-- Bootstrap button to edit the user. Once again, technically this does not need to be in the form. However I added it here
otherwise it would not be inline with the delete button. The link matches the name of the following route:
Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('users.edit');
this route calls the edit function in UserController and it will add the id of the user to the wildcard in the
endpoint-->
            <a href="{{ route('users.accounts.edit', $user) }}" class="btn btn-primary btn-block"
               role="button">Edit</a>
            <a href="{{ route('users.accounts.password', $user) }}" class="btn btn-warning btn-block"
               role="button">Change Password</a>
            <a href="{{route("dashboard")}}" class="btn btn-danger btn-block">Back</a>

        </div>
        <!-- /.card-body -->
    </div>
            </div>
        </div>
    </div>
    <!-- /.card -->

    <!-- The Modal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body" id="modalBody">
                    Modal body..
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
    <script>
        var msgPassword = '{{Session::get('alertPassword')}}';
        var existPassword = '{{Session::has('alertPassword')}}';
        if(existPassword){
            if(msgPassword=="1")
            {
                $("#modalBody").html("Successfully Changed Password!");
                $('#myModal').modal('show');
            }
            else
            {
                $("#modalBody").html("Password Change Failed!");
                $('#myModal').modal('show');
            }
        }

        var msgAccount = '{{Session::get('alertAccount')}}';
        var existAccount = '{{Session::has('alertAccount')}}';
        if(existAccount){
            if(msgAccount=="1")
            {
                $("#modalBody").html("Successfully Updated Account!");
                $('#myModal').modal('show');
            }
            else
            {
                $("#modalBody").html("Account Update Failed!");
                $('#myModal').modal('show');
            }
        }
    </script>
@endsection





