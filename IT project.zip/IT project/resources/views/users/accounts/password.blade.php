@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Change Password - {{$user->name}}</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - The action of the form is the following route:
          Route::put('/users/{user}', [UserController::class, 'update'])->name('users.update');
          This calls the update method of the UserController to update our user.
          Notice it is a POST form but our route needs a PUT.... -->
        <form role="form" method="POST" action="{{ route('users.accounts.updatePassword', $user) }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
        @csrf
        <!-- override the POST method with a PUT so we have a put method. We need to do this as browsers
                                do not support PUT via 'HTML form' submission -->
            @method('PUT')
            <div class="card-body">
                <div class="form-group">
                    <label for="currentPassword">Current Password</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="password" maxlength="191" class="form-control" name="currentPassword" id="currentPassword" placeholder="Enter the current password..." required>
                    @error('currentPassword')
                        <p class="text-danger">{{$errors->first('currentPassword')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="password">New Password</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="password" maxlength="191" class="form-control" name="password" id="password" placeholder="Enter the new password..." required>
                    @error('password')
                        <p class="text-danger">{{$errors->first('password')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="password_confirmation">Confirm Password</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="password" maxlength="191" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm the new password..." required>
                    @error('password_confirmation')
                        <p class="text-danger">{{$errors->first('password_confirmation')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            </div>
            <!-- /.card-body -->
        </form>
    </div>
    <!-- /.card -->


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
