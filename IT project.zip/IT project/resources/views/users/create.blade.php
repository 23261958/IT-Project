@extends('template.layout')

@section('head')
    <!-- any extra css if required in the head -->
@endsection

@section('contentBody')

    <!-- using bootstrap cards to lay the page out. A bootstrap card is a flexible and extensible content container,
    see https://getbootstrap.com/docs/4.0/components/card/.
    You can also look at our template documentation https://adminlte.io/docs/3.0/components/cards.html for more examples
     of cards -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">New User</h3>
        </div>
        <!-- /.card-header -->

        <!-- form start - notice it is a POST form as we are posting data. The action of the form is the following route:
         Route::post('/users', [UserController::class, 'store']);
         This calls the store method of the UserController to store our new user -->
        <form role="form" method="POST" action="{{ route('users') }}">

            <!-- generates a CSRF "token" for each active user session managed by the application - see https://laravel.com/docs/7.x/csrf -->
            @csrf
            <div class="card-body">
                <div class="form-group">
                    <label for="name">Name</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="name" id="name" placeholder="Enter the user name..." value="{{old('name')}}" required>
                    @error('name')
                        <p class="text-danger">{{$errors->first('name')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="email" id="email" placeholder="Enter the user email address..." value="{{old('email')}}" required>
                    @error('email')
                        <p class="text-danger">{{$errors->first('email')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="email_confirmation">Confirm Email</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="text" maxlength="191" class="form-control" name="email_confirmation" id="email_confirmation" placeholder="Confirm the user email address..." required>
                    @error('email_confirmation')
                        <p class="text-danger">{{$errors->first('email_confirmation')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="password" maxlength="191" class="form-control" name="password" id="password" placeholder="Enter the user password..." value="{{old('password')}}" required>
                    @error('password')
                        <p class="text-danger">{{$errors->first('password')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="password_confirmation">Confirm Password</label>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the users table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    <input type="password" maxlength="191" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm the user password..." required>
                    @error('password_confirmation')
                        <p class="text-danger">{{$errors->first('password_confirmation')}}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="roles">Roles</label><br>
                    <!-- notice the name and id of the input. The two inputs match the fields in the database for the units table.
                    You must have these so that when we post the data we can get it from the request.
                    Notice the input is required so we can validate that a user has entered it as this field is not nullable in the database
                     -->
                    @foreach($roles as $role)
                        <span>{{$role->role_name}}</span>
                        <input type="checkbox" name="roles[]" id="roles{{$role->id}}" value="{{$role->id}}" class="mr-4">
                    @endforeach
                    @error('roles')
                    <p class="text-danger">{{$errors->first('roles')}}</p>
                    @enderror
                </div>
                <!-- submit the form -->
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{url()->previous()}}" class="btn btn-danger">Back</a>
            <!-- /.card-body -->
            </div>
        </form>

    </div>
    <!-- /.card -->


@endsection

@section('javascript')
    <!-- any extra js if required at the end of the page -->
@endsection
